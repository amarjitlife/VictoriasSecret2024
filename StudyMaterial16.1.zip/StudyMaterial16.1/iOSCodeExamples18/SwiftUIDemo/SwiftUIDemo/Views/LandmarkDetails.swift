//
//  LandmarkDetails.swift
//  SwiftUIDemo
//
//  Created by Amarjit Singh on 19/06/24.
//

import SwiftUI

struct LandmarkDetails: View { 
    var landmark: Landmark
    
    var body: some View {
        /*VStack*/ 
        ScrollView {
            MapView(coordinate: landmark.locationCoordinates)
                .frame(height: 300 )
            
            CircleImage(image: landmark.image)
                .offset( y: -130 )
                .padding( .bottom, -130 )
            
            VStack( alignment: .center ) {
                Text( landmark.name )
                    .font(.title)
                    .foregroundColor(.blue)
                
                HStack {
//                    Text("Bennergatha National Park")
                    Text(landmark.park )
                        .font(.subheadline)
                    Spacer()
//                    Text("Bangalore")
                    Text( landmark.state )
                        .font(.subheadline)
                }
                .font(.subheadline)
                .foregroundStyle(.secondary)
                
                Divider()
//                Text("About Turtle Rock!")
                Text("About \(landmark.name)")
                    .font(.title2)
//                Text("This is the turtle rock......")
                Text(landmark.description)
                Spacer()

            }.padding()
        }
        .navigationTitle(landmark.name)
        .navigationBarTitleDisplayMode(.inline)
    }
}


#Preview {
    LandmarkDetails(landmark: landmarks[0])
}
