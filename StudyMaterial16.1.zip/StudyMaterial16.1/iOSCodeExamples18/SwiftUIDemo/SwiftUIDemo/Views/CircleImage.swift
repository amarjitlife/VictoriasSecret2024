//
//  CircleImage.swift
//  SwiftUIDemo
//
//  Created by Amarjit Singh on 19/06/24.
//

import SwiftUI

struct CircleImage: View {
    var image: Image
    var body: some View {
//        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
//        Image("turtlerock")
//            .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
//            .overlay {
//                Circle().stroke(.gray, lineWidth: 4.0)
//            }
//            .shadow( radius: 7 )
        image
    }
}

#Preview {
    CircleImage(image: Image("turtlerock"))
}
