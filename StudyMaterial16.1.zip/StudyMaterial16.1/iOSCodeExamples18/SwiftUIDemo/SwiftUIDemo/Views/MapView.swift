//
//  MapView.swift
//  SwiftUIDemo
//
//  Created by Amarjit Singh on 19/06/24.
//

import SwiftUI
import MapKit

struct MapView: View {
    var coordinate: CLLocationCoordinate2D
    
    var body: some View {
        //        Text("Hello, World!")
//        Map(initialPosition: .region(region) )
        Map( position: .constant(.region(region)))
    }
    
    private var region: MKCoordinateRegion {
        MKCoordinateRegion(
//            center: CLLocationCoordinate2D(latitude: 100.0, longitude: 100.0),
            center: coordinate,
            span: MKCoordinateSpan(latitudeDelta: 0.2, longitudeDelta: 0.2)
        )
    }
}


#Preview {
    MapView(coordinate: landmarks[0].locationCoordinates )
}
