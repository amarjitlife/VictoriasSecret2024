//
//  SwiftUIDemoApp.swift
//  SwiftUIDemo
//
//  Created by Amarjit Singh on 19/06/24.
//

import SwiftUI

@main
struct SwiftUIDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
