//
//  AppDelegate.swift
//  TabViewController
//
//  Created by Amarjit Singh on 31/05/24.
//

//REMOVING SCENE DELEGATE
//  Remove SceneDelegate.swift file
//  Remove Application Scene Manifest from Info.plist file
//  Add var window: UIWindow? to AppDelegate.swift
//  Replace @main with @UIApplicationMain
//  Remove UISceneSession Lifecycle ( functions ) in AppDelegate

import UIKit

//@main
@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        // Override point for customization after application launch.
        print("Function: \(#function) Called..." )
        // Create Window
        self.window = UIWindow(frame: UIScreen.main.bounds)
        // Override point for customization after application launch.
        self.window!.backgroundColor = UIColor.white
        
        // Creating ViewController Instance
        let viewController: UIViewController = ViewController()
        
        // Making Window Aware About ViewController
        self.window?.rootViewController = viewController
        self.window!.makeKeyAndVisible()

        return true
    }

    /*
    // MARK: UISceneSession Lifecycle

    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }
    */

}

