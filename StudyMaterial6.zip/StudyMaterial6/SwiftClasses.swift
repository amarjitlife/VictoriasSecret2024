//____________________________________________________________
//____________________________________________________________

// In Swift
//		Int, Float, Double, Character, String Are Value Types
//      Tuple Is Value Type
//      Arrays Are Value Types
//      Dictionary Are Value Type
//		Structures Are Value Types 
//		Enums Are Value Types

// In Swift
//		Closures Are Reference Types
//      Classes Are References Type

//____________________________________________________________

struct Resolution {
	var width 	= 0 // Default Values
	var height 	= 0 // Default Values
}

var someResolution = Resolution()
print( someResolution )

print( someResolution.width )
print( someResolution.height )

// Value Assignment 
let someResolutionAgain = someResolution
print( someResolution )
print( someResolutionAgain )

someResolution.width 	= 800
someResolution.height 	= 900
print( someResolution )
print( someResolutionAgain )

// Resolution(width: 0, height: 0)
// Resolution(width: 0, height: 0)
// Resolution(width: 800, height: 900)
// Resolution(width: 0, height: 0)

//____________________________________________________________

var someArray = [10, 20, 30, 40, 50, 60]

// Value Assignment
let someArrayAgain = someArray

print( someArray )
print( someArrayAgain )
someArray[0] = 111
someArray[1] = 222
someArray[2] = 333
someArray[3] = 444
print( someArray )
print( someArrayAgain )

// [10, 20, 30, 40, 50, 60]
// [10, 20, 30, 40, 50, 60]
// [111, 222, 333, 444, 50, 60]
// [10, 20, 30, 40, 50, 60]

// In Swift 
//		Closures Are Reference Types

//____________________________________________________________

// Enclosing Function
func makeIncrementor(forIncrement amount: Int) -> () -> Int {
    // Local Variable: Lifetime Till makeIncrementor Scope
    var runningTotal = 0

    // Enclosed Function
    func incrementor() -> Int {
        runningTotal += amount
        return runningTotal
    }
    return incrementor
    // Lcoal Variable Will Die
}

let incrementByTen = makeIncrementor(forIncrement: 10)
print( incrementByTen() )
print( incrementByTen() )
print( incrementByTen() )

let incrementBySeven = makeIncrementor(forIncrement: 7)
print( incrementBySeven() )
print( incrementBySeven() )
print( incrementByTen() )
print( incrementByTen() )

// Closure In Swift Are Reference Types
// Reference Assignment
let incrementByTenAgain = incrementByTen
print( incrementByTenAgain() )
print( incrementByTenAgain() )
// 10

//____________________________________________________________

// In Swift: Tuples Are Value Type
var someTuple = (10, 20, 30)
let someTupleAgain = someTuple

print( someTuple )
print( someTupleAgain )
someTuple.0 = 100

print( someTuple )
print( someTupleAgain )

// (10, 20, 30)
// (10, 20, 30)
// (100, 20, 30)
// (10, 20, 30)

//____________________________________________________________

// In Swift: Dictionary Are Value Type

var someDictionary = [ 10 : "Ding", 20 : "Dong", 30 : "Ting", 40 : "Tong "]
let someDictionaryAgain = someDictionary

print( someDictionary )
print( someDictionaryAgain )

someDictionary[10] = "Modi"
print( someDictionary )
print( someDictionaryAgain )

//____________________________________________________________

// In Swift: Classes Are References Type

class VideoMode {
    var resolution = Resolution()
    var frameRate = 0.0
    var interlaced = false
    var name: String?
}

var someVideoMode = VideoMode()
// Reference Assignment
let someVideoModeAgain = someVideoMode

print( someVideoMode.frameRate )
print( someVideoModeAgain.frameRate )
someVideoMode.frameRate = 60.0

print( someVideoMode.frameRate )
print( someVideoModeAgain.frameRate )

// 60.0
// 60.0

print( someVideoMode )
print( someVideoModeAgain )


//____________________________________________________________

let vga = Resolution( width: 640, height: 480 )
print( vga )

let hd = Resolution( width: 1920, height: 1080 )
var cinema = hd
cinema.width = 2048

print( hd.width )
print( cinema.width )

//____________________________________________________________

// In Swift: Enums Are Value Type

enum CompassPoint {
    case North, South, East, West
}

var currentDirection = CompassPoint.West
let rememberDirection = currentDirection

currentDirection = .East

print( currentDirection )
print( rememberDirection )

// East
// West

//____________________________________________________________

let tenEighty = VideoMode()
tenEighty.resolution = hd
tenEighty.interlaced = true
tenEighty.name = "1080i"
tenEighty.frameRate = 25.0

let alsoTenEighty = tenEighty
alsoTenEighty.frameRate = 30.0
print("tenEighty.frameRate")
print("alsoTenEighty.frameRate")

// Identity Operators
if tenEighty === alsoTenEighty {
    print("tenEighty and alsoTenEighty refer to the same VideoMode instance.")
} else {
    print("Both Objects Are Different")
}

// Pointers
// A Swift constant or variable that refers to an instance of some 
// reference type is similar to a pointer in C, 
// but is not a direct pointer to an address in memory.

//____________________________________________________________
//____________________________________________________________
//____________________________________________________________
//____________________________________________________________
//____________________________________________________________
//____________________________________________________________


