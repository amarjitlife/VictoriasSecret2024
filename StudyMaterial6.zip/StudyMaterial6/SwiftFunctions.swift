
func sayHello(personName: String) -> String {
    let greeting = "Hello, " + personName + "!"
    return greeting
}

print( sayHello(personName: "Anna") )
print( sayHello(personName: "Brian") )

func sayHelloAgain(personName: String) -> String {
    return "Hello, " + personName + "!"
}
print( sayHelloAgain(personName: "Anna") )
// print( sayHelloAgain( "Anna" ) )


func halfOpenRangeLength(start: Int, end: Int) -> Int {
    return end - start
}
print(halfOpenRangeLength(start: 1, end: 10))


func sayHelloWorld() -> String {
    return "hello, world"
}
print(sayHelloWorld())



func sayGoodbye(personName: String) {
    print("Goodbye, \(personName)!")
}
sayGoodbye(personName: "Dave")

func printAndCount(stringToPrint: String) -> Int {
    print(stringToPrint)
    return stringToPrint.count
}

func printWithoutCounting(stringToPrint: String) {
    printAndCount(stringToPrint: stringToPrint)
}
printAndCount(stringToPrint: "hello, world")
printWithoutCounting(stringToPrint: "hello, world")

// ___________________________________________________________
// ___________________________________________________________


func minMax( array: [Int] ) -> (min: Int, max: Int) {
	var currentMin = array[0]
	var currentMax = array[0]

	for value in array[1..<array.count] {
		if value < currentMin {
			currentMin = value
		} else if  value > currentMax {
			currentMax = value
		}
	}

	return ( currentMin, currentMax )
}

let bounds = minMax( array: [10, 20, 30, 40, 89, 90] )
print("Bounds: \(bounds)")


// ___________________________________________________________
// ___________________________________________________________

func someFunction( externalParameterName localParameterName: Int ) -> Int {
	return localParameterName
}

print( someFunction( externalParameterName: 999) ) 

// ___________________________________________________________


func join(s1: String, s2: String, joiner: String) -> String {
    return s1 + joiner + s2
}
join(s1: "hello", s2: "world", joiner: ", ") // Parameter meanings are not clear


func join(string s1: String, toString s2: String, withJoiner joiner: String) -> String {
    // return s1 + joiner + s2
    return join(s1: s1, s2: s2, joiner: joiner)
}
join(string: "Hello", toString: "World", withJoiner: ", ")


// ___________________________________________________________


// Shorthand External Parameter Names
func containsCharacter(string: String, characterToFind: Character) -> Bool {
    for character in string {
        if character == characterToFind {
            return true
        }
    }
    return false
}

let containsAVee = containsCharacter(string: "aardvark", characterToFind: "v")

// ___________________________________________________________


// Polymorphic Functions
//		Using Mechanism: Default Arguments
func joinAgain(string s1: String, toString s2: String, withJoiner joiner: String = " ") -> String {
    // return s1 + joiner + s2
    return join(s1: s1, s2: s2, joiner: joiner)
}

print( joinAgain(string: "Hello", toString: "World", withJoiner: ", ") )
print( joinAgain(string: "Hello", toString: "World") )


// ___________________________________________________________

// Polymorphic Function
//		Using Mechanims: Varidiac Arguments
func arithmeticMean( numbers: Double... ) -> Double {
	var total: Double = 0
	for number in numbers {
		total += number
	}

	return total / Double( numbers.count )
}

print( arithmeticMean( ) )
print( arithmeticMean( numbers: 10, 20, 30) )
print( arithmeticMean( numbers: 10, 20, 30, 40, 50 ) )
print( arithmeticMean( numbers: 10, 20, 30, 40, 50, 60, 70, 80, 90 ) )

// ___________________________________________________________

func alignRight( string: String, totalLength: Int, pad: Character) -> String {
    var stringResult: String = ""
    let amountToPad = totalLength - string.count
    if amountToPad < 1 {
        return string
    }

    let padString = String(pad)
    for _ in 1...amountToPad {
        stringResult = padString + string
    }
    return stringResult
}

let originalString = "hello"
let paddedString = alignRight(string: originalString, totalLength: 20, pad: "-")
print( paddedString )


// ___________________________________________________________

var someArray: [Int] = [10, 20, 30, 40, 50]

// error: cannot assign through subscript: 'array' is a 'let' constant
//    array[0] = 999
func doChange( array: [Int] ) {
// error: cannot assign through subscript: 'array' is a 'let' constant
    // array[0] = 999
}

print( someArray )
doChange( array: someArray )
print( someArray )

// ___________________________________________________________

func swapTwoInts( a: Int, b: Int) {
    // var aa = a
    // var bb = b
    // let temp = aa
    // aa = bb
    // bb = temp 

    var a = a
    var b = b
    let temp = a
    a = b
    b = temp 
}

func swapInts( a: inout Int, b: inout Int) {
    let temp = a
    a = b
    b = temp 
}

var someInt = 20
var anotherInt = 100

print( someInt, anotherInt )
swapTwoInts( a: someInt, b: anotherInt )
print( someInt, anotherInt )

print( someInt, anotherInt )
swapInts( a: &someInt, b: &anotherInt )
print( someInt, anotherInt )

// ___________________________________________________________

// Function Type
//      (Int, Int) -> Int
func addTwoInts( a: Int, b: Int ) -> Int {
    return a + b
}

// Function Type
//      (Int, Int) -> Int
func multiplyTwoInts(a: Int, b: Int) -> Int {
    return a * b
}

var mathFunction: (Int, Int) -> Int = addTwoInts
var result = mathFunction( 100, 200 )
print("\nResult : \(result)")

mathFunction = multiplyTwoInts
result = mathFunction( 100, 200 )
print("\nResult : \(result)")

// Higher Order Function
//      Function Takes Function Arguments And/Or Returns Functions
func printResult( x: Int, y: Int, doSomething : (Int, Int) -> Int ) {
    let result = doSomething(x, y)
    print("\nResult : \(result)")
}

printResult(x: 100, y: 1000, doSomething: addTwoInts ) 
printResult(x: 100, y: 1000, doSomething: multiplyTwoInts )

// Higher Order Function
//      Function Takes Function Arguments And/Or Returns Functions
// Pure Function: Mathematical Function
//      Output Only Depends On Input


// Function Type
//      (Int, Int, (Int, Int) -> Int ) -> Int

func calculateResult( x: Int, y: Int, doSomething : (Int, Int) -> Int ) -> Int {
    let result = doSomething(x, y)
    return result
}

let somethingAgain: (Int, Int, (Int, Int) -> Int) -> Int = calculateResult

result = calculateResult(x: 100, y: 200, doSomething: addTwoInts )
print( result )
result = calculateResult(x: 100, y: 200, doSomething: multiplyTwoInts )
print( result )

result = somethingAgain( 100, 200, addTwoInts )
print( result )
result = somethingAgain( 100, 200, multiplyTwoInts )
print( result )

// ___________________________________________________________

// Function Type
//      (Int, Int) -> Int
func sum(x: Int, y: Int ) -> Int { return x + y }
func sub(x: Int, y: Int ) -> Int { return x - y }
func mul(x: Int, y: Int ) -> Int { return x * y }
func div(x: Int, y: Int ) -> Int { return x * y }


// Function Type
//      (Int, Int, (Int, Int) -> Int ) -> Int
func calculator(x: Int, y: Int, operation: (Int, Int) -> Int ) -> Int {
    return operation(x, y)
}

result = calculator(x: 10, y: 20, operation: sum)
print( result )
result = calculator(x: 10, y: 20, operation: sub)
print( result )
result = calculator(x: 10, y: 20, operation: mul)
print( result )

// ___________________________________________________________

func stepForward( input: Int ) -> Int {
    return input + 1
}

func stepBackward( input: Int ) -> Int {
    return input - 1
}

// Higher Order Functions:
//              Functions Which Can Return Functions
func chooseStepFunction( backwards: Bool ) -> (Int) -> Int {
    return backwards ? stepBackward : stepForward
}

func moveTowardsZero(startValue: Int) {
    var currentValue = startValue
    let moveNearerToZero: (Int) -> Int = chooseStepFunction( backwards : currentValue > 0 )

    while( currentValue != 0 ) {
            print("Current Value: \(currentValue)")
            currentValue = moveNearerToZero( currentValue )
    }

    print("Reached Zero!!! : \(currentValue)")
}

moveTowardsZero( startValue: 5 )
moveTowardsZero( startValue: -5 )

let somethingMore = moveTowardsZero
let somethingOnceMore: (Bool) -> (Int) -> Int = chooseStepFunction

// ___________________________________________________________

func chooseStepFunction1( backwards: Bool ) -> (Int) -> Int {
        func stepForward( input: Int ) -> Int  { return input + 1 }
        func stepBackward( input: Int ) -> Int { return input - 1 }

        return backwards ? stepBackward : stepForward
}

func moveTowardsZero1(startValue: Int) {
        var currentValue = startValue
        let moveNearerToZero : (Int) -> Int = chooseStepFunction1( 
                                                    backwards : currentValue > 0 )

        while( currentValue != 0 ) {
                print("Current Value: \(currentValue)")
                currentValue = moveNearerToZero( currentValue )
        }

        print("Reached Zero!!! : \(currentValue)")
}

moveTowardsZero1( startValue: 5 )
moveTowardsZero1( startValue: -5 )

// ___________________________________________________________

/*
var names = ["Chris", "Alex", "Ewa", "Barry", "Daniella"]

func backwards(s1: String, s2: String) -> Bool {
    return s1 > s2
}

var reversed = names.sort(by: backwards)

reversed = names.sort( { (s1:String, s2: String) -> Bool in return s1 > s2 } )
reversed = names.sort( { s1, s2 in return s1 > s2 })
reversed = names.sort({ s1, s2 in s1 > s2 })
reversed = names.sort({ $0 > $1 })
reversed = names.sort(>)

// Trailing Closures/Lambda Expression


func someFunctionThatTakesAClosure(closure: () -> ()) {
    
}

someFunctionThatTakesAClosure( {} )
someFunctionThatTakesAClosure() {
    
}

*/

/*
let digitNames = [0: "Zero", 1: "One", 2: "Two", 3: "Three", 4:"Four", 5: "Five", 6:"Six", 7: "Seven", 8: "Eight", 9: "Nine"]
let numbers = [16, 58, 510]

let strings = numbers.map {
    (number) -> String in
    var number = number
    var output = ""
    while number > 0 {
        output = digitNames[number % 10]! + output
        number = number / 10
    }
    return output
}

print( strings )
*/

// ___________________________________________________________

// Enclosing Function
func makeIncrementor(forIncrement amount: Int) -> () -> Int {
    // Local Variable: Lifetime Till makeIncrementor Scope
    var runningTotal = 0

    // Enclosed Function
    func incrementor() -> Int {
        runningTotal += amount
        return runningTotal
    }
    return incrementor
    // Lcoal Variable Will Die
}

let incrementByTen = makeIncrementor(forIncrement: 10)
print( incrementByTen() )
print( incrementByTen() )
print( incrementByTen() )

let incrementBySeven = makeIncrementor(forIncrement: 7)
print( incrementBySeven() )
print( incrementBySeven() )
print( incrementByTen() )
print( incrementByTen() )

// Closure In Swift Are Reference Types
// Reference Assignment
let incrementByTenAgain = incrementByTen
print( incrementByTenAgain() )
print( incrementByTenAgain() )
// 10
// 20
// 30
// 7
// 14
// 40
// 50
// 60
// 70

// ___________________________________________________________
// ___________________________________________________________
// ___________________________________________________________
// ___________________________________________________________
// ___________________________________________________________


