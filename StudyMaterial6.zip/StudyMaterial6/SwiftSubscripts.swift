
struct TimesTable {
    let multiplier: Int

    // subscript Is Special Function
    //      Used To Overload Subscript Operator
    //      Taking One Argument Of Int Type and Returning Int Value
    subscript(index: Int) -> Int {
        print("Subscript Called...")
        return multiplier * index
    }
}

let threeTimesTable = TimesTable(multiplier: 3)

// Using Overloaded Subscript Operator
// Compiler Will Generate Following Code For Below Line Of Code
//      let something = threeTimesTable.subscript( index: 6 )
let something = threeTimesTable[6] // threeTimesTable.subscript( index: 6 )
print("six times three is \(something)")

// Output For Above Code Example
// Subscript Called...
// six times three is 18

//_______________________________________________________
// 
// Inbuilt Subscript Operator Usage With Dictionary
var numberOfLegs = ["spider": 8, "ant": 6, "cat": 4]
numberOfLegs["bird"] = 2

//_______________________________________________________
// >>>>>>> MOMENT YOU ARE DONE! PLEASE RAISE YOUR HAND!!!
//_______________________________________________________

// Simulating 2-Dimentional Matrix [ 2D Array ] On Top Of 1-Dimentional Array

struct Matrix {
    let rows: Int, columns: Int

    // Internal Data Structure 1 Dimentional
    //      Will Become Basis To Simulate Higher Dimentions
    var grid: [Double]

    // In Swift init Function Is A Constructor 
    init(rows: Int, columns: Int) {
        self.rows = rows
        self.columns = columns
        grid = Array(repeating: 0.0, count: rows * columns)
    }

    func indexIsValid(row: Int, column: Int) -> Bool {
        return row >= 0 && row < rows && column >= 0 && column < columns
    }

    subscript(row: Int, column: Int) -> Double {
        get {
            assert(indexIsValid(row: row, column: column), "Index out of range")
            // Converting 2-Dimentional Indices [ row, column ] To 1-Dimentional Index
            return grid[ (row * columns) + column ]
        }

        set {
            assert(indexIsValid(row: row, column: column), "Index out of range")
            // Converting 2-Dimentional Indices [ row, column ] To 1-Dimentional Index
            grid[(row * columns) + column] = newValue
        }
    }
}

var matrix = Matrix(rows: 2, columns: 2)
print( matrix )
matrix[0, 1] = 1.5
matrix[1, 0] = 3.2

print( matrix )


//_______________________________________________________
//
// >>>>>>> MOMENT YOU ARE DONE! PLEASE RAISE YOUR HAND!!!
//_______________________________________________________

// Type Subscript
// Instance subscripts, as described above, are subscripts that you call 
// on an instance of a particular type. 
// You can also define subscripts that are called on the type itself. 
// This kind of subscript is called a type subscript. 
// You indicate a type subscript by writing the static keyword 
// before the subscript keyword. 
// Classes can use the class keyword instead, to allow subclasses 
// to override the superclass’s implementation of that subscript.

enum Planet: Int {
    case Mercury = 1, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune

    // substript Binded With Type
    static subscript( index: Int ) -> Planet {
        return Planet( rawValue: index )!
    }
}

//         Using Subscript Operator With Type
let mars = Planet[4]
print( mars )
print( mars.rawValue )

let something1 = Planet[1]
print( something1 )
print( something1.rawValue )

// let something11 = Planet[0]
// print( something11 )

//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________


