
//_______________________________________________________
// DEINITIALISERS

// deinit {

// }

class Human {
	var id : Int = 0
	var name: String = "[Unnamed]"

	init(id: Int, name: String) {
		print("Human: init Called...")
		self.id 	= id
		self.name 	= name
	}

	deinit {
		print("Human: deinit Called...")		
	}
}

var gabbar: Human? = Human(id: 420, name: "Gabbar Singh")
// Use if-let Idiom For Following Line Of Code
print( gabbar!.id, gabbar!.name )

gabbar = nil


//_______________________________________________________

// Class definitions can have at most one deinitializer per class. 
// The deinitializer does not take any parameters and is written without parentheses:

struct Bank {
    static var coinsInBank = 10_000

    static func vendCoins(numberOfCoinsToVend: Int) -> Int {
        let numberOfCoinsToVend1 = min(numberOfCoinsToVend, coinsInBank)
        coinsInBank -= numberOfCoinsToVend1
        return numberOfCoinsToVend
    }

    static func receiveCoins(coins: Int) {
        coinsInBank += coins
    }
}

class Player {
    var coinsInPurse: Int
    
    init(coins: Int) {
        coinsInPurse = Bank.vendCoins(numberOfCoinsToVend: coins)
    }
    
    func winCoins(coins: Int) {
        coinsInPurse += Bank.vendCoins(numberOfCoinsToVend: coins)
    }
    
    deinit {
        Bank.receiveCoins(coins: coinsInPurse)
    }
}

var playerOne: Player? = Player(coins: 100)
print("A new player has joined the game with \(playerOne!.coinsInPurse) coins")
print("There are now \(Bank.coinsInBank) coins left in the bank")

playerOne!.winCoins(coins: 2_000)
print("PlayerOne won 2000 coins & now has \(playerOne!.coinsInPurse) coins")
print("The bank now only has \(Bank.coinsInBank) coins left")

playerOne = nil
print("PlayerOne has left the game")
print("The bank now has \(Bank.coinsInBank) coins")
print( Bank.coinsInBank )  // This should be back to 10_000. The playerOne variable doesn't get deinitialized in the playground because the GUI keeps it around in case it is referred to again I presume.


//_______________________________________________________
//_______________________________________________________
//_______________________________________________________

