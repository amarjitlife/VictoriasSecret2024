
// Basic Operators

// Assignment operator
let b = 10
var a = 5
a = b

let (x, y) = (1, 2)

/*
// “Unlike the assignment operator in C and Objective-C, 
// The assignment operator in  Swift does not itself return a value. 
// The following statement is not valid:”

if x = y {
    
}
*/

// Arithmetic Operators
1 + 2
5 - 3
2 * 3
10.0 / 2.5
// Swift Arithmetic operators can't overflow

"hello, " + "world"

let dog: Character = "🐶"

//let dogcow = dog + cow // This has been removed from the book.
let dogcow = "🐶" + "🐮"


// Remainder Operator
9 % 4
// a = (b × some multiplier) + remainder
-9 % 4
// a % b and a % -b
9 % -4
-9 % -4


// Increment and Decrement Operators
var i = 0
//++i

var aa = 0
//let bb = ++aavar

//let c = aa++
aa

// Unary Minus Operator
let three = 3
let minusThree = -three
let plusThree = -minusThree

// Unary Plus Operator
// Doesn't do anything
let minusSix = -6
let alsoMinusSix = +minusSix

// Compound Assignment Operators
var aaa = 1
aaa += 2

// Comparison Operators
1 == 1
2 != 1
2 > 1
1 < 2
1 >= 1
2 <= 1

//____________________________________________________________

// In Java Following Code
//		String Constants Only One Copy Stored For Duplicates
let name = "world"
if name == "world" {
    print("hello, world")
} else {
    print("I'm sorry \(name), but I don't recognize you")
}

//____________________________________________________________

//NOTE
//The Swift standard library includes tuple comparison operators for 
// tuples with fewer than seven elements. 
// To compare tuples with seven or more elements, you must implement 
// the comparison operators yourself.

(1, "zebra") < (2, "apple")   // true because 1 is less than 2; "zebra" and "apple" are not compared
(3, "apple") < (3, "bird")    // true because 3 is equal to 3, and "apple" is less than "bird"
(4, "dog") == (4, "dog")      // true because 4 is equal to 4, and "dog" is equal to "dog"

("blue", -1) < ("purple", 1)        // OK, evaluates to true
//("blue", false) < ("purple", true)  // Error because < can't compare Boolean values


// Identity operators
// “Swift also provides two identity operators (=== and !==), 
// which you use to test whether two object references both 
// refer to the same object instance.”

// Ternary Conditional Operator
// let contentHeight = 40
// let hasHeader = true
// let rowHeight = contentHeight + (hasHeader ? 50 : 20)

let contentHeight = 50
let hasHeader = false
//let rowHeight = contentHeight + ( (hasHeader) ? 50 : 20 )
var choiceValue = ( hasHeader ? 50 : (contentHeight == 40) ? 10 : 100  )
print("Choice Value Using Ternary Operator: ", choiceValue)



if hasHeader {
    choiceValue = 50
} else if ( contentHeight == 40 ) {
    choiceValue = 10
} else {
    choiceValue = 100
}
print("Choice Value Using if-else Construct: ", choiceValue)

if hasHeader {
    choiceValue = 50
} else {
    choiceValue = (contentHeight == 40) ? 10 : 100
}
print("Choice Value Using if-else+Ternary: ", choiceValue)

let rowHeight = contentHeight + choiceValue
print(rowHeight)


// Range Operators
// The Closed Range Operator
for index in 1...5 {
    print("\(index) times 5 is \(index * 5)")
}

// The Half-Closed Range Operator
let names0 = ["Anna", "Alex", "Brian", "Jack"]
let count = names0.count

for i in 0..<count {
    print("Person \(i + 1) is called \(names0[i])")
}

let names = [ "Ding", "Dong", "King", "Kong", "Ting", "Tong" ]
let namesCount = names.count
print(names)

print()
for i in 0..<namesCount {
    print("Person at \(i) is: \(names[i])")
}


for name in names {
    print("Person Name: \(name)")
}

print()
for name in names[2...] {
    print("Person Name: \(name)")
}

print()
for name in names[...2] {
    print("Person Name: \(name)")
}

print()
for name in names[..<2] {
    print("Person Name: \(name)")
}

print()
for name in names[2...5] {
    print("Person Name: \(name)")
}

let range1 = 1...10
print(range1)
for value in range1 {
    print(value)
}


let range2 = ...10
print(range2)
// Runtime Error: Not provided starting value
// for value in range2 {
//     print(value)
// }

let range3 = 1...
print(range3)
// Infinite Loop
// for value in range3 {
//     print(value)
//}

for value in range3 {
    if value == 100 { break }
    print(value)
}

//____________________________________________________________

// Logical Operators
let allowedEntry = false
if !allowedEntry {
    print("ACCESS DENIED")
}

let enteredDoorCode = true
let passedRetinaScan = false
if enteredDoorCode && passedRetinaScan {
    print("Welcome!")
} else {
    print("ACCESS DENIED")
}

let hasDoorKey = false
let knowsOverridePassword = true
if hasDoorKey || knowsOverridePassword {
    print("Welcome")
} else {
    print("ACCESS DENIED")
}

if enteredDoorCode && passedRetinaScan || hasDoorKey || knowsOverridePassword {
    print("Welcome!")
} else {
    print("ACCESS DENIED")
}

if (enteredDoorCode && passedRetinaScan) || hasDoorKey || knowsOverridePassword {
    print("Welcome!")
} else {
    print("ACCESS DENIED")
}


//____________________________________________________________

for index in 1...5 {
    print("\(index) times 5 is \(index * 5)")
}

let base = 3
let power = 10
var answer = 1

for _ in 1...power {
    answer *= base
}

let names = ["Anna", "Alex", "Brian", "Jack"]
for name in names {
    print("Hello, \(name)!")
}

let numberOfLegs = ["spider": 8, "ant": 6, "cat": 4]
for (animalName, legCount) in numberOfLegs {
    print("\(animalName)s have \(legCount) legs")
}


// for var index = 0; index < 3; ++index {
//     print("index = \(index)")
// }

// var index: Int
// for index = 0; index < 3; ++index {
//     print("index is \(index)")
// }
// print("The loop statements were executed \(index) times")




//____________________________________________________________

let finalSquare = 25
var board = [Int](repeating: 0, count: finalSquare + 1)

board[03] = +08; board[06] = +11; board[09] = +09; board[10] = +02
board[14] = -10; board[19] = -11; board[22] = -02; board[24] = -08

var square = 0
var diceRoll = 0
while square < finalSquare {
    // roll the dice
    if ++diceRoll == 7 { diceRoll = 1 }
    // move by the rolled amount
    square += diceRoll
    if square < board.count {
        // if we're still on the board, move up or down for a snake or a ladder
        square += board[square]
    }
}
print("Game over!")


// Repeat-While

square = 0
diceRoll = 0
repeat {
    // move up or down for a snake or ladder
    square += board[square]
    // roll the dice
    if ++diceRoll == 7 { diceRoll = 1 }
    // move by the rolled amount
    square += diceRoll
} while square < finalSquare
print("Game over!")

var temperatureInFarenheit = 30
if temperatureInFarenheit <= 32 {
    print("It's very cold. Consider wearing a scarf")
}

temperatureInFarenheit = 40
if temperatureInFarenheit <= 32 {
    print("It's very cold. Consider wearing a scarf")
} else {
    print("It's not that cold. wear a t-shirt.")
}

temperatureInFarenheit = 90
if temperatureInFarenheit <= 32 {
    print("It's very cold. Consider wearing a scarf")
} else if temperatureInFarenheit >= 86 {
    print("It's really warm. Don't forget to wear sunscreen.")
} else {
    print("It's not that cold. wear a t-shirt.")
}

temperatureInFarenheit = 72
if temperatureInFarenheit <= 32 {
    print("It's very cold. Consider wearing a scarf")
} else if temperatureInFarenheit >= 86 {
    print("It's really warm. Don't forget to wear sunscreen.")
}

//____________________________________________________________

let minutes = 60
for tickMark in 0..<minutes {
    // render the tick mark each minute (60 times)
}
let minuteInterval = 5
for tickMark in stride(from: 0, to: minutes, by: minuteInterval) {
    // render the tick mark every 5 minutes (0, 5, 10, 15 ... 45, 50, 55)
}

let hours = 12
let hourInterval = 3
for tickMark in stride(from: 3, through: hours, by: hourInterval) {
    // render the tick mark every 3 hours (3, 6, 9, 12)
}

//____________________________________________________________

let weatherAdvice = if temperatureInCelsius <= 0 {
    "It's very cold. Consider wearing a scarf."
} else if temperatureInCelsius >= 30 {
    "It's really warm. Don't forget to wear sunscreen."
} else {
    "It's not that cold. Wear a T-shirt."
}


print(weatherAdvice)
// Prints "It's not that cold. Wear a T-shirt."

let freezeWarning: String? = if temperatureInCelsius <= 0 {
    "It's below freezing. Watch for ice!"
} else {
    nil
}

let freezeWarning1 = if temperatureInCelsius <= 0 {
    "It's below freezing. Watch for ice!"
} else {
    nil as String?
}

let weatherAdvice1 = if temperatureInCelsius > 100 {
    throw TemperatureError.boiling
} else {
    "It's a reasonable temperature."
}



//____________________________________________________________
//____________________________________________________________
//____________________________________________________________
//____________________________________________________________
//____________________________________________________________



