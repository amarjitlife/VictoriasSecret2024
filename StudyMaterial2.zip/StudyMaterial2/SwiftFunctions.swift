
func sayHello(personName: String) -> String {
    let greeting = "Hello, " + personName + "!"
    return greeting
}

print( sayHello(personName: "Anna") )
print( sayHello(personName: "Brian") )

func sayHelloAgain(personName: String) -> String {
    return "Hello, " + personName + "!"
}
print( sayHelloAgain(personName: "Anna") )
// print( sayHelloAgain( "Anna" ) )


func halfOpenRangeLength(start: Int, end: Int) -> Int {
    return end - start
}
print(halfOpenRangeLength(start: 1, end: 10))


func sayHelloWorld() -> String {
    return "hello, world"
}
print(sayHelloWorld())



func sayGoodbye(personName: String) {
    print("Goodbye, \(personName)!")
}
sayGoodbye(personName: "Dave")

func printAndCount(stringToPrint: String) -> Int {
    print(stringToPrint)
    return stringToPrint.count
}

func printWithoutCounting(stringToPrint: String) {
    printAndCount(stringToPrint: stringToPrint)
}
printAndCount(stringToPrint: "hello, world")
printWithoutCounting(stringToPrint: "hello, world")

// ___________________________________________________________
// ___________________________________________________________


func minMax( array: [Int] ) -> (min: Int, max: Int) {
	var currentMin = array[0]
	var currentMax = array[0]

	for value in array[1..<array.count] {
		if value < currentMin {
			currentMin = value
		} else if  value > currentMax {
			currentMax = value
		}
	}

	return ( currentMin, currentMax )
}

let bounds = minMax( array: [10, 20, 30, 40, 89, 90] )
print("Bounds: \(bounds)")


// ___________________________________________________________
// ___________________________________________________________

func someFunction( externalParameterName localParameterName: Int ) -> Int {
	return localParameterName
}

print( someFunction( externalParameterName: 999) ) 

// ___________________________________________________________


func join(s1: String, s2: String, joiner: String) -> String {
    return s1 + joiner + s2
}
join(s1: "hello", s2: "world", joiner: ", ") // Parameter meanings are not clear


func join(string s1: String, toString s2: String, withJoiner joiner: String) -> String {
    // return s1 + joiner + s2
    return join(s1: s1, s2: s2, joiner: joiner)
}
join(string: "Hello", toString: "World", withJoiner: ", ")


// ___________________________________________________________


// Shorthand External Parameter Names
func containsCharacter(string: String, characterToFind: Character) -> Bool {
    for character in string {
        if character == characterToFind {
            return true
        }
    }
    return false
}

let containsAVee = containsCharacter(string: "aardvark", characterToFind: "v")

// ___________________________________________________________


// Polymorphic Functions
//		Using Mechanism: Default Arguments
func joinAgain(string s1: String, toString s2: String, withJoiner joiner: String = " ") -> String {
    // return s1 + joiner + s2
    return join(s1: s1, s2: s2, joiner: joiner)
}

print( joinAgain(string: "Hello", toString: "World", withJoiner: ", ") )
print( joinAgain(string: "Hello", toString: "World") )


// ___________________________________________________________

// Polymorphic Function
//		Using Mechanims: Varidiac Arguments
func arithmeticMean( numbers: Double... ) -> Double {
	var total: Double = 0
	for number in numbers {
		total += number
	}

	return total / Double( numbers.count )
}

print( arithmeticMean( ) )
print( arithmeticMean( numbers: 10, 20, 30) )
print( arithmeticMean( numbers: 10, 20, 30, 40, 50 ) )
print( arithmeticMean( numbers: 10, 20, 30, 40, 50, 60, 70, 80, 90 ) )

// ___________________________________________________________

func alignRight( string: String, totalLength: Int, pad: Character) -> String {
    var stringResult: String = ""
    let amountToPad = totalLength - string.count
    if amountToPad < 1 {
        return string
    }

    let padString = String(pad)
    for _ in 1...amountToPad {
        stringResult = padString + string
    }
    return stringResult
}

let originalString = "hello"
let paddedString = alignRight(string: originalString, totalLength: 20, pad: "-")
print( paddedString )


// ___________________________________________________________
// ___________________________________________________________
// ___________________________________________________________
// ___________________________________________________________
// ___________________________________________________________
// ___________________________________________________________


