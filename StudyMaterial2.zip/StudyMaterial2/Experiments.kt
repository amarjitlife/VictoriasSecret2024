
package learnKotlin

//______________________________________________________

fun playWithTypeInferrencingAndBinding() {
	// 1. Type Inferring From RHS
	// 2. Type Binding To LHS
	//		Inferred Type Is Binded To LHS

	//In  Kotlin, Java, C, C++ 
	//		Statically Typed Langauge
	//		Type Is Compile Time Decision
	// In Python
	//		Type Is Runtime Decision

	val something = 10
	println( something )

	// Explicitly Annotating Type Of LHS As Int
	val somethingAgain: Int = 10
	println( somethingAgain )

	val something1 = 90.90
	val somethingAgain1: Double = 90.90
	println( something1 )
	println( somethingAgain1 )

	val something2 = 90.90F
	val somethingAgain2: Float = 90.90F
	println( something2 )
	println( somethingAgain2 )

	val greeting = "Good Evening!"
	val greetingAgain : String = "Good Evening!"
	println( greeting )
	println( greetingAgain )
}

//______________________________________________________

fun playWithIntialValues() {
	val something: Int
	println( something )

	// Explicitly Annotating Type Of LHS As Int
	val somethingAgain: Int = 10
	println( somethingAgain )

	val something1: Double
	val somethingAgain1: Double = 90.90
	println( something1 )
	println( somethingAgain1 )

	val something2: Float
	val somethingAgain2: Float = 90.90F
	println( something2 )
	println( somethingAgain2 )

	val greeting: String
	val greetingAgain : String = "Good Evening!"
	println( greeting )
	println( greetingAgain )
}

//______________________________________________________
//______________________________________________________
//______________________________________________________
//______________________________________________________

fun main() {
	println("\nFunction: playWithTypeInferrencingAndBinding")
	playWithTypeInferrencingAndBinding()

	println("\nFunction: playWithIntialValues")
	playWithIntialValues()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}