
#include <stdio.h>

void playWithPointers() {
	int a = 20;
	int *ptr = &a;

	printf("\n Value of a: %d", a);
	printf("\n Value At Address ptr: %d", *ptr);	

	printf("\n Address of a: %x", &a);	
	printf("\n Address of a: %x", ptr);	
}

int main() {
	printf("\n\nFunction: playWithPointers");
	playWithPointers();
}

