

// VALID SUM
#include <stdio.h>
#include <limits.h>

//____________________________________________________

void playWithHelloWorld() {
  printf("\nHello World!!!");
}

//____________________________________________________
  
signed int sum(signed int a, signed int b) {
  signed int result = 0;
  if (((b > 0) && (a > (INT_MAX - b))) ||
      ((b < 0) && (a < (INT_MIN - b)))) {
    /* Handle error */
  	// printf("\nCan't Calculate Sum For Given a And b");
    // throw Exception;
    // Return Error;
  } else {
    	result = a + b;
  }
  
  return result;
}

//____________________________________________________

void playWithRanges() {
    char something = -128;

    for( ; something < 128 ; something++ ) {
      printf("\n%d", something );
    }
}

//____________________________________________________

void playWithIf() {
  int x = 90;

  if( x ) {
    printf("Oyee Hoyee!!");
  } else {
    printf("Aaayee Haayee!!!");
  }
}


//____________________________________________________

int sum(int x, int y, int *error) {
  if ( NotOverflow ) {
    return x + y;
  } else {
    *error = 1;
  }
}

void playWithSum() {
   int a = 1000;
   int b = 2000;
   int result = 0;
   int error = 0;

   result = sum(a, b, &error);
   if ( !(*error) ) {
      printf("\n Result : %d", result);
   }
}

//____________________________________________________

typedef struct result_type {
    int value;
    int valid;
} Result;

Result sumBeter(int x, int y) {
  Result result;

  if ( NotOverflow ) {
    result.value = x + y;
    result.valid = 1;
  } else {
    result.valid = 0;
  }

  return result;
}

void playWithSum() {
   int a = 1000;
   int b = 2000;
   Result result = 0;
   int error = 0;

   result = sum(a, b, &error);
   if ( result.valid ) {
      printf("\n Result : %d", result.value);
   }
}

//____________________________________________________

typedef struct optional_type {
    int value;
    int valid;
} Optional;

Optional sumBeter(int x, int y) {
  Optional result;

  if ( NotOverflow ) {
    result.value = x + y;
    result.valid = 1;
  } else {
    result.valid = 0;
  }

  return result;
}

void playWithSum() {
   int a = 1000;
   int b = 2000;
   Optional result = 0;
   int error = 0;

   result = sum(a, b, &error);
   if ( result.valid ) {
      printf("\n Result : %d", result.value);
   }
}


//____________________________________________________

typedef struct optional_type {
    int value;
    int valid;
} Optional;

Optional sumBeter(int x, int y) {
  Optional result;

  if ( 1 ) {
    result.value = x + y;
    result.valid = 1;
  } else {
    result.valid = 0;
  }

  return result;
}

void playWithSum() {
   int a = 1000;
   int b = 2000;
   Optional result = 0;
   int error = 0;

   result = sum(a, b, &error);
   if ( result.valid ) {
      printf("\n Result : %d", result.value);
   }
}


//____________________________________________________

void playWithAuthentication() {
  char username[5] 
  char password[100];
  int a[] = {10, 20, 30, 40, 50}; 
  
  int i = sum(a, b);

  for ( , i < 5 ; i++ ) {
    printf("\n %d", a[i]);
  }
}


//____________________________________________________

// // In C/C++/Java
// int sub(int x, int y) {
//   return x + y
// }


// // In ObjectiveC

// (int) subx: (int) y: (int) {

// }


//____________________________________________________


//____________________________________________________

int main() {
  printf("\n\nFunction: playWithHelloWorld");
  playWithHelloWorld();

  // printf("\n\nFunction: playWithRanges");
  // playWithRanges();

  printf("\n\nFunction: playWithIf");
  playWithIf();

  // printf("\n\nFunction: "); 
  // printf("\n\nFunction: ");
  // printf("\n\nFunction: ");
  // printf("\n\nFunction: ");
  // printf("\n\nFunction: "); 
  // printf("\n\nFunction: ");

  return 0;
}

