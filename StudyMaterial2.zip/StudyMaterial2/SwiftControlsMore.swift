
//____________________________________________________________

let minutes = 60
for tickMark in 0..<minutes {
    // render the tick mark each minute (60 times)
}
let minuteInterval = 5
for tickMark in stride(from: 0, to: minutes, by: minuteInterval) {
    // render the tick mark every 5 minutes (0, 5, 10, 15 ... 45, 50, 55)
}

let hours = 12
let hourInterval = 3
for tickMark in stride(from: 3, through: hours, by: hourInterval) {
    // render the tick mark every 3 hours (3, 6, 9, 12)
}

//____________________________________________________________

var temperatureInFahrenheit = 30

let temperatureInCelsius = 25
// let weatherAdvice: String

let weatherAdvice = if temperatureInCelsius <= 0 {
    "It's very cold. Consider wearing a scarf."
} else if temperatureInCelsius >= 30 {
    "It's really warm. Don't forget to wear sunscreen."
} else {
    "It's not that cold. Wear a T-shirt."
}


print(weatherAdvice)
// Prints "It's not that cold. Wear a T-shirt."

// All of the branches of an if expression need to contain values of the same type. 
// Because Swift checks the type of each branch separately, values 
// like nil that can be used with more than one type prevent 
// Swift from determining the if expression’s type automatically. 
// Instead, you need to specify the type explicitly —

let freezeWarning: String? = if temperatureInCelsius <= 0 {
    "It's below freezing. Watch for ice!"
} else {
    nil
}

let freezeWarning1 = if temperatureInCelsius <= 0 {
    "It's below freezing. Watch for ice!"
} else {
    nil as String?
}

let weatherAdvice1 = if temperatureInCelsius > 100 {
    // throw TemperatureError.boiling
    "Boiling..."
    // let a = 90
    // "Boiling"
} else {
    "It's a reasonable temperature."
}

//____________________________________________________________


// Switch


let someCharacter: Character = "e"
switch someCharacter {
    case "a", "e", "i", "o", "u":
        print("\(someCharacter) is a vowel")
    case "b", "c", "d", "f", "g", "h", "j", "k", "l", "m", "n", "p", "q", "r", "s", "t", "v", "w", "x", "y", "z":
        print("\(someCharacter) is a consonant")
    default:
        print("\(someCharacter) is not a vowel or consonant")
}


// No Implicit Fallthrough


let anotherCharacter: Character = "a"
switch anotherCharacter {
    //case "a": // Not valid if this line is in place as no executble line for this case statement.
    case "A":
        print("The letter A")
    default:
        print("Not the letter A")
}


// Interval Matching


let approximateCount = 62
let countedThings = "moons orbiting Saturn"
var naturalCount: String
switch approximateCount {
case 0:
    naturalCount = "no"
case 1..<5:
    naturalCount = "a few"
case 5..<12:
    naturalCount = "several"
case 12..<100:
    naturalCount = "dozens of"
case 100..<1000:
    naturalCount = "hundreds of"
default:
    naturalCount = "manu"
}
print("There are \(naturalCount) \(countedThings).")


// Note: Both the closed range operator (...) and half-open range operator (..<) functions
        // are overloaded to return either an IntervalType or Range. 
        // An interval can determine whether it contains a particular element, such as when matching a switch statement case. 
        // A range is a collecton of consecutive values, which can be iterated on in a for-in statement.


// Tuples


let somePoint = (1,1)
switch somePoint {
case (0, 0):
    print("(0,0) is at the origin")
case (_, 0):
    print("\(somePoint.0),0) is on the x-axis")
case (0, _):
    print("(0, \(somePoint.1)) is on the y-axis")
case (-2...2, -2...2):
    print("(\(somePoint)) is inside the box")
default:
    print("(\(somePoint)) is outside of the box")
}


// Value Bindings


let anotherPoint = (2, 0)
switch anotherPoint {
case (let x, 0):
    print("on the x-axis with an x value of \(x)")
case (0, let y):
    print("on the y-axis with a y value of \(y)")
case let (x, y):
    print("somewhare else at (\(x), \(y))")
}


// Where


let yetAnotherPoint = (1, -1)
switch yetAnotherPoint {
case let (x, y) where x == y:
    print("(\(x), \(y)) is on the line x == y")
case let (x, y) where x == -y:
    print("(\(x), \(y)) is on the line x == -y")
case let (x, y):
    print("(\(x), \(y)) is just some arbitrary point")
}



//____________________________________________________________
//____________________________________________________________
//____________________________________________________________
//____________________________________________________________



