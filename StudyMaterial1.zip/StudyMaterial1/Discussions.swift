

Write Following sum Function In C

Calculate Aritmatic Integer Sum 
	Return Valid Aritmatic Sum
	OR
	Print Can't Calculate Sum For Given Values

//______________________________________________

// ATTEMPT 01
int sum(int x, int y) {
	return x + y 
}

//______________________________________________

// ATTEMPT 02
int sum(int x, int y) {
	int total = x + y

	if ( total > x + y || total < x + y ) {

	}
    else {

    }
}

//______________________________________________

// ATTEMPT 03
int sum(int x, int y) {
	int total = x + y

	if ( ( x, y > 0 &&  total < 0 ) || ( x, y < 0 and total > 0 )) {

	}
    else {

    }
}

//______________________________________________
//______________________________________________
//______________________________________________

