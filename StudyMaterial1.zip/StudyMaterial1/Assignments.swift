
____________________________________________________________

DAY 01
____________________________________________________________

	Assignment A1 : Reading Assignment [ MUST MUST ]

		Data Type Chapter
		The C Programming Language, 2nd Edition, Kernigham and Denish Ritchie

	Assignment A2 : Thinking, Exploration and Experimentation

____________________________________________________________

DAY 02
____________________________________________________________
	
	Assignment A0 : Practice and Revision Swift Code [ MUST MUST ]
		Practice Swift Code Till Now Done
		Compare Similar Ideas In Java and Kotlin
		Write Sample Codes and Find The Differences

	Assignment A1 : Reading Assignment [ MUST MUST ]
		Chapter: Types, Expressions and Operators
		Reference: 
			The C Programming Language, 2nd Edition
			By Kernigham and Denish Ritchie

	Assignment A2 : Thinking, Exploration and Experimentation
		Lot More Coding Assignment

