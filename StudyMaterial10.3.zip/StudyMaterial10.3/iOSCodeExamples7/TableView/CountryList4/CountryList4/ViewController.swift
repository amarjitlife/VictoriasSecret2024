//
//  ViewController.swift
//  CountryList4
//
//  Created by Nagarajan on 8/27/14.
//  Copyright (c) 2014 Nagarajan. All rights reserved.
//

import UIKit

class ViewController: UIViewController , UITableViewDelegate, UITableViewDataSource {
    
    var tableView: UITableView!
    var countryList:[String] = ["Afghanistan", "Bahrain", "Bangladesh", "Bhutan",
        "Brunei", "Cambodia", "China", "East Timor", "India",
        "Indonesia", "Iran", "Iraq", "Israel", "Japan", "Jordan",
        "Kazakhstan", "Korea North", "Korea South", "Kuwait", "Kyrgyzstan",
        "Laos", "Lebanon", "Malaysia", "Maldives", "Mongolia", "Myanmar (Burma)",
        "Nepal", "Oman", "Pakistan", "The Philippines", "Qatar", "Russia",
        "Saudi Arabia", "Singapore", "Sri Lanka", "Syria", "Taiwan", "Tajikistan",
        "Thailand", "Turkey", "Turkmenistan", "United Arab Emirates", "Uzbekistan",
        "Vietnam", "Yemen"]
    
    let cellIdentifier = "CountryCell"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func loadView()
    {
        super.loadView()
        self.tableView = UITableView(frame: CGRect(x: 0, y: 100, width: self.view.bounds.size.width, height: self.view.bounds.size.height - 100), style: UITableView.Style.plain)
        self.tableView.delegate = self;
        self.tableView.dataSource = self;
        self.view.addSubview(self.tableView)
        
        let button: UIButton! = UIButton(type: UIButton.ButtonType.system)
        button.setTitle("EditTable", for:UIControl.State())
        button.addTarget(self, action: #selector(ViewController.editTable), for: .touchUpInside)
        button.frame = CGRect(x: 0, y: 50, width: 100, height: 50)
        self.view.addSubview(button as UIView)
    }
    
    override var prefersStatusBarHidden : Bool
    {
        return true
    }
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1;
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return self.countryList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        var cell = tableView.dequeueReusableCell(withIdentifier: self.cellIdentifier)
        if cell == nil
        {
            cell = UITableViewCell(style: UITableViewCell.CellStyle.default, reuseIdentifier: self.cellIdentifier)
        }
        var count = 0
        if (self.tableView.isEditing && indexPath.row != 0)
        {
            count = 1
        }
        if(indexPath.row == (self.countryList.count) && self.tableView.isEditing)
        {
            cell!.textLabel?.text = "Add a new Cell"
            return cell!
        }
        cell!.textLabel?.text = self.countryList[indexPath.row]
        return cell!
    }
    
    @objc func editTable()
    {
        if(self.tableView.isEditing)
        {
            self.tableView.setEditing(false, animated: false)
            self.tableView.reloadData()
            /*var button:UIButton = self.view.subviews[1] as UIButton
            button.setTitle("Edit", forState: .Normal)*/
        }
        else
        {
            self.tableView.setEditing(true, animated: true)
            self.tableView.reloadData()
            /*var button:UIButton = self.view.subviews[1] as UIButton
            button.setTitle("Done", forState: .Normal)*/
        }
    }
    
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool
    {
        return true
    }
    
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle
    {
        if(self.tableView.isEditing == false)
        {
            return UITableViewCell.EditingStyle.none
        }
        else if(self.tableView.isEditing && indexPath.row == self.countryList.count)
        {
            return UITableViewCell.EditingStyle.insert
        }
        else
        {
            return UITableViewCell.EditingStyle.delete
        }
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath)
    {
        if(editingStyle == UITableViewCell.EditingStyle.delete)
        {
            self.countryList.remove(at: indexPath.row)
            self.tableView.reloadData()
        }
        else if(editingStyle == UITableViewCell.EditingStyle.insert)
        {
            self.countryList.insert("New Country", at: self.countryList.count)
            self.tableView.reloadData()
        }
    }

}

