//____________________________________________________________
//____________________________________________________________

// In Swift
//		Int, Float, Double, Character, String Are Value Types
//		Structures Are Value Types 
//		Arrays Are Value Types
//		Enums Are Value Types

// In Swift
//		Closures Are Reference Types

//____________________________________________________________

struct Resolution {
	var width 	= 0 // Default Values
	var height 	= 0 // Default Values
}

var someResolution = Resolution()
print( someResolution )

print( someResolution.width )
print( someResolution.height )

// Value Assignment 
let someResolutionAgain = someResolution
print( someResolution )
print( someResolutionAgain )

someResolution.width 	= 800
someResolution.height 	= 900
print( someResolution )
print( someResolutionAgain )

// Resolution(width: 0, height: 0)
// Resolution(width: 0, height: 0)
// Resolution(width: 800, height: 900)
// Resolution(width: 0, height: 0)

//____________________________________________________________

var someArray = [10, 20, 30, 40, 50, 60]

// Value Assignment
let someArrayAgain = someArray

print( someArray )
print( someArrayAgain )
someArray[0] = 111
someArray[1] = 222
someArray[2] = 333
someArray[3] = 444
print( someArray )
print( someArrayAgain )

// [10, 20, 30, 40, 50, 60]
// [10, 20, 30, 40, 50, 60]
// [111, 222, 333, 444, 50, 60]
// [10, 20, 30, 40, 50, 60]

// In Swift 
//		Closures Are Reference Types

//____________________________________________________________

// Enclosing Function
func makeIncrementor(forIncrement amount: Int) -> () -> Int {
    // Local Variable: Lifetime Till makeIncrementor Scope
    var runningTotal = 0

    // Enclosed Function
    func incrementor() -> Int {
        runningTotal += amount
        return runningTotal
    }
    return incrementor
    // Lcoal Variable Will Die
}

let incrementByTen = makeIncrementor(forIncrement: 10)
print( incrementByTen() )
print( incrementByTen() )
print( incrementByTen() )

let incrementBySeven = makeIncrementor(forIncrement: 7)
print( incrementBySeven() )
print( incrementBySeven() )
print( incrementByTen() )
print( incrementByTen() )

// Closure In Swift Are Reference Types
// Reference Assignment
let incrementByTenAgain = incrementByTen
print( incrementByTenAgain() )
print( incrementByTenAgain() )
// 10

//____________________________________________________________
//____________________________________________________________
//____________________________________________________________
//____________________________________________________________
//____________________________________________________________
//____________________________________________________________
//____________________________________________________________
