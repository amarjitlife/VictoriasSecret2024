
//__________________________________________________________

print("Hello World!")

print("你好")

//__________________________________________________________

// Mutable State
var myVariable = 42
print( myVariable )
myVariable = 100
print( myVariable )


let myConstant = 99
print( myConstant )
// myConstant = 100
// print( myConstant )

// DESIGN PRINCIPLE
//		Design Towards Immutability Rather Mutability

let something0 = 90
let something1 = 0x100
let something2 = 0o700
let something3 = 0b10101

//__________________________________________________________


let maximumNumberOfLoginAttempts = 10
var currentLoginAttempt = 0

var x = 0.0, y = 0.0, z = 0.0

//: ### Type Annotations
var welcomeMessage: String
welcomeMessage = "Hello"

print( welcomeMessage )
//: ### Naming Constants and Variables

let π = 3.14159
let 你好 = "你好世界"
let 🐶🐮 = "dogcow"

var friendlyWelcome = "Hello!"
friendlyWelcome = "Bonjour!"

let languageName = "Swift"


print(friendlyWelcome)

print(π, 你好, 🐶🐮 )
print(π, 你好, 🐶🐮, separator: " -- ", terminator: " ### ")

print("The current value of friendlyWelcome is \(friendlyWelcome)")


//: ## Comments

// this is a comment

/* this is also a comment, but written over multiple lines*/

/* this is the start of the first multiline comment
/* this is the second, nested multiline comment */
this is the end of the first multiline comment */


let cat = "🐱"; print(cat)


//__________________________________________________________


let minValue = UInt8.min
let maxValue = UInt8.max

print(minValue, maxValue)


let minValue0 = Int8.min
let maxValue0 = Int8.max
print(minValue0, maxValue0)


var someValue: Int8 = 127
print( someValue )
// someValue = someValue + 1
someValue = someValue &+ 1

print( someValue )

var twoThousand: UInt16 = 2000
let one: UInt8 = 1

// let twoThousandOne = twoThousand + one
// print( twoThousandOne )

// let twoThousandOne = UInt8( twoThousand ) + one
// let twoThousandOne = UInt8( twoThousand ) &+ one
let twoThousandOne = twoThousand + UInt16( one )

print( twoThousandOne )

let twoThousandOneAgain = 2000 + 1
print( twoThousandOneAgain )


let descimalInteger = 17
let binaryInteger = 0b10001
let octalInteger = 0o21
let hexadecimalInteger = 0x11

print( descimalInteger )
print( binaryInteger )
print( octalInteger )
print( hexadecimalInteger )

let decimalDouble = 12.1875
let exponentDouble = 1.21875e1
let hexadecialDouble = 0xC.3p0

let paddedDouble = 000123.456
let oneMillion = 1_000_000
let justOverOneMillion = 1_000_000.000_000_1

let three = 3
let pointOneFourOneFiveNine = 0.14159
// let pi2 = three + pointOneFourOneFiveNine
// let pi2 = Double(three) + pointOneFourOneFiveNine
// let integerPi = Int(pi2)


let integerFourPointSeven = Int(4.75)
let integerNegativeThreePointNine = Int(-3.9)
print( integerFourPointSeven )
print( integerNegativeThreePointNine )

// Compiler Optimistation
//		Constant Folding
let somethingSome = 3 + 0.14159
print( somethingSome )

// DESIGN PRINCILES
//		EXPLICIT PROGRAMMING IS BETTER THAN IMPLICIT
//		YOU SHOULD NOT PAY FOR IT IF YOU ARE NOT USING IT

typealias AudioSample = UInt16
var macAmplitudeFound = AudioSample.min
let somethingAgain: AudioSample = 90

// Int8, UInt8
// Int16, UInt16
// Int32, UInt32
// Int

//__________________________________________________________

let i = 1
/*
if i {
    
}
*/

if i == 1 {
    
}

//__________________________________________________________

var http404Error = (404, "Not Found")

// Unpacking Tuple
// Decomposing Tuple
let (statusCode, statusMessage) = http404Error
print( statusCode, statusMessage )

var http404Error1: (Int, String) = (404, "Not Found")
let (statusCode1, statusMessage1) = http404Error1
print( statusCode1, statusMessage1 )

// http404Error = ( 900, 999 )

let (justTheStatusCode, _) = http404Error
print("The status code is \(justTheStatusCode)")

print( http404Error.0 )
print( http404Error.1 )

//?? Is It Tuple Type Or Int Type
// It's Int Type
var http404ErrorAgain: (Int) = (404)
print( http404ErrorAgain )
//http404ErrorAgain = "Ding"


let http404 = (status: 404, message: "Not Found")
print( http404.status, http404.message )

//__________________________________________________________

// DESIGN PRINCIPLE
//		DESIGN TOWARDS NON NULLABILITY RATHER THAN NULLABILITY
//		Bring Nullability Only With Strong Reasoning
//		If Nullability Is There Handle It As Early As Possible
//		Resist The Temptation To Propogate Nullability
//		Exceptions Are Not That Exceptional Such That It Break Your Design
//			i.e. Excpetions Must Be Used As Last Resport

// In Swift/Kotlin
//		Non Nullable Types Are Default

// In Java/C/C++
//		Nullable Types Are Default

// Non Nullable Types
var somethingMore: Int = 90
print( somethingMore ) // 90

// somethingMore = nil

// Optional Types || Nullable Types
var somethingMore1: Int? = 90
print( somethingMore1! ) // Optional(90)

somethingMore1 = nil 
// print( somethingMore1! ) // nil
// print( somethingMore1 ) // nil

//		If Nullability Is There Handle It As Early As Possible
if somethingMore1 != nil {
	print( somethingMore1! ) // nil
} else {
	print("Nothingness Found!!!")
}

//__________________________________________________________

var possibleNumber = "123ABC"
// let convertedNumber = Int( possibleNumber )
let convertedNumber0: Int? = Int( possibleNumber )

// print( convertedNumber )
if convertedNumber0 != nil {
	print( convertedNumber0! )
} else {
	print("Nothingness Found!!!")
}

possibleNumber = "123"
// Idioms 01 : if-let

// Optional Binding
if let convertedNumber = Int(possibleNumber) {
	print( convertedNumber )
} else {
	// print( convertedNumber )
	print("Nothingness Found!!!")
}

// For Idioms 01 : if-let Compiler Will Generate Following Code
let convertedNumberTemp: Int? = Int( possibleNumber )
if convertedNumberTemp != nil {
	let convertedNumber: Int = convertedNumberTemp!
	print( convertedNumber )
} else {
	print("Nothingness Found!!!")
}

// Idioms 02 : if-let 
if let firstNumber = Int("40"), let secondNumber = Int("99"),  firstNumber < secondNumber {
	// firstNumber = nil
	print( firstNumber, secondNumber )
} else {
	print( "Criteria Failed...")
}

// For Idioms 02 : if-let Compiler Will Generate Following Code
let firstNumberTemp: Int? = Int("40")
let secondNumberTemp: Int? = Int("99")

// let firstNumber: Int 	= firstNumberTemp!
// let secondNumber: Int 	= secondNumberTemp!
if firstNumberTemp != nil && secondNumberTemp != nil { 
	let firstNumber: Int 	= firstNumberTemp!
	let secondNumber: Int 	= secondNumberTemp!

	if firstNumber < secondNumber {
		print( firstNumber, secondNumber )
	} else {
		print( "Criteria Failed...")
	}
} else {
	print( "Criteria Failed...")
}

// Idioms 03 : if-var 
if var convertedNumber = Int(possibleNumber) {
	print( convertedNumber )
	convertedNumber = 999
	print( convertedNumber )	
} else {
	// print( convertedNumber )
	print("Nothingness Found!!!")
}

let a: Int? = 40
let b: Int? = nil
let c: Int? = 90

// Idioms 04 : if-let 
if let A = a, let B = b, let C = c {
	print(A, B, C)
} else {
	print("Somewhere is Nothingness!!!")
}

// For Idioms 04 : if-let Compiler Will Generate Following Code
if a != nil && b != nil && c != nil {
	let A = a!
	let B = b!
	let C = c!
	print(A, B, C)
} else {
	print("Somewhere is Nothingness!!!")
}

//__________________________________________________________

let number: Int
number = 10
print( number )

// Following Two Lines Are Equivalent
let numberAgain = 90
let numberAgain1: Int = 90

print( numberAgain ) 

print( numberAgain1 ) 

//__________________________________________________________


let possibleString: String? = "How are you doing?"
let forcedUnwrappedString: String = possibleString!

print( forcedUnwrappedString )


//: ### Implicitly Unwrapped Optionals
//: Implicitly unwrapped optionals are useful when an optional’s 
// value is confirmed to exist immediately after the optional is 
// first defined and can definitely be assumed to exist at every 
// point thereafter. 

// The primary use of implicitly unwrapped optionals in Swift 
// is during class initialization

// Implicitly Unwrapped Value
let assumedString: String! = "All Well!"
let implicitString : String = assumedString

print( assumedString! )
print( implicitString )


//__________________________________________________________

func canThrowAnError() throws {
    // this function may or may not throw an error
}

do {
    try canThrowAnError()
    // no error was thrown
} catch {
    // an error was thrown
}

//__________________________________________________________
//__________________________________________________________
//__________________________________________________________

/* In Java/C++
Human h = new Human();
if ( h != null ) {
	h.dance()
} else {
	printf("Nothinness Found");
}
*/


//__________________________________________________________

/*
https://codebunk.com/b/3381100663970/
https://codebunk.com/b/3381100663970/
https://codebunk.com/b/3381100663970/
https://codebunk.com/b/3381100663970/
*/

//__________________________________________________________

