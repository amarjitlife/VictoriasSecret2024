
print("Hello World!")

print("你好")

// Mutable State
var myVariable = 42
print( myVariable )
myVariable = 100
print( myVariable )


let myConstant = 99
print( myConstant )
// myConstant = 100
// print( myConstant )

// DESIGN PRINCIPLE
//		Design Towards Immutability Rather Mutability

let something0 = 90
let something1 = 0x100
let something2 = 0o700
let something3 = 0b10101

// Type Is Int

//1. Type Inferrencing
//2. Type Binding
let somethingInt0 = 90
let somethingInt1 = 0x100
let somethingInt2 = 0o700
let somethingInt3 = 0b10101

let implicitDouble = 90.90
let explicitDouble: Double = 90.90

// let greeting = "Do Something: " + 900
// let something

let label = "The width is "
let width = 94
let widthLabel = label + String(width)

let apples = 3
let oranges = 5
let appleSummary = "I have \(apples) apples"
let fruitSummary = "I have \(apples + oranges) pieces of fruit"

print( appleSummary )
print( fruitSummary )

let π: Float = 3.14
let name = "Peter Pie"
let piePy = "\(name) likes the number \(π)"
print(π)
print(name)
print(piePy)

let नमसत = "Hello!!! Jagtee Rahoo!!!"
print( नमसत )

let 😊 = "Keep Smiling"
print( 😊 )


let shoppingList = ["Butter", "Eggs", "Chicken", "Beer" ]
print( shoppingList )

// shoppingList[0] = "Ice"
// print( shoppingList )

var shoppingListAgain = ["catfish", "water", "tulips", "blue paint"]
print( shoppingListAgain )

shoppingListAgain[1] = "bottle of water"
print( shoppingListAgain )

let emptyArray = [String]()
var emptyDictionary = [String: Float]()

shoppingList = []
emptyDictionary = [:]

/*
https://codebunk.com/b/3381100663970/
https://codebunk.com/b/3381100663970/
https://codebunk.com/b/3381100663970/
*/


