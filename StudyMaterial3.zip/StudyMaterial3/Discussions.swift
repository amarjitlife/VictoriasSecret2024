

Write Following sum Function In C

Calculate Aritmatic Integer Sum 
	Return Valid Aritmatic Sum
	OR
	Print Can't Calculate Sum For Given Values

//______________________________________________

// ATTEMPT 01
int sum(int x, int y) {
	return x + y 
}

//______________________________________________

// ATTEMPT 02
int sum(int x, int y) {
	int total = x + y

	if ( total > x + y || total < x + y ) {

	}
    else {

    }
}

//______________________________________________

// ATTEMPT 03
int sum(int x, int y) {
	int total = x + y

	if ( ( x, y > 0 &&  total < 0 ) || ( x, y < 0 and total > 0 )) {

	}
    else {

    }
}

//______________________________________________

fun outerFunction() {
	var something = 100

	fun localFunction() {
		something = something + 1000
	}

	return ::localFunction
}


val somethingAgain = outerFunction()

val magic = somethingAgain()


//______________________________________________


String greeting = new String("Hello");
greeting = new String("Ola");


//______________________________________________

String greeting = new String("Hello");

void doChange( String something ) {
	something = String("Ola");
}

doChange( greeting );
print( greeting );


//______________________________________________

f1() {
	f11() {

	}
	f12() {

	}
	f13() {

	}
}

f2() {
	f22() {

	}
	f23() {

	}
}

main() {
	f1()
	f2()
}


//______________________________________________

{ L
	{ L1
		{ L11

		}
		
		{ L12

		}
		
		{ L13

		}
	}

	{ L2
		{ L21

		}
		
		{ L22
			
		}
	}
}

//______________________________________________
//______________________________________________
//______________________________________________
//______________________________________________
//______________________________________________
//______________________________________________
//______________________________________________

