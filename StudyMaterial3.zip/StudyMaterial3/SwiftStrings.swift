// Strings and Characters

let someString = "Some tring literal value"


// Initializing an Empty Strings
var emptyString = ""
var anotherEmpyString = String()

if emptyString.isEmpty {
    print("Nothing to see here")
}

// String mutability
var variableString = "Horse"
variableString += " and carriage"


let constantString = "Highlander"
//  error: left side of mutating operator isn't mutable: 'constantString' is a 'let' constant
// constantString += " and another Highlander" // There can be only one

for character in "Dog!🐶" {
    print(character)
}

let exclamationMark0 = "!"
let exclamationMark: Character = "!"

let catCharacters: [Character] = ["C", "a", "t", "!", "🐱"]
let catString = String(catCharacters)
print(catString)

// Concatenating Strings and Characters
let string1 = "Hello"
let string2 = " there"
var welcome = string1 + string2
// Welcome now equals "hellow there"

var instruction = "look over"
instruction += string2

welcome.append(exclamationMark)

// String Interpolation
let multiplier = 3
let message = "\(multiplier) times 2.5 is \(Double(multiplier) * 2.5)"

// Special Characters in String Literals
let wiseWords = "\"Imagination is more important than knowledge\" - Einstein"

// "Imagination is more important than knowledge" - Einstein
let dollarSign = "\u{24}"           // $,  Unicode scalar U+0024
let blackHeart = "\u{2665}"         // ♥,  Unicode scalar U+2665
let sparklingHeart = "\u{1F496}"    // 💖, Unicode scalar U+1F496
let puppy = "\u{1F436}"

print( dollarSign )
print( blackHeart )
print( sparklingHeart )
print( puppy )

// Extended Grapheme Clusters
let eAcute: Character = "\u{E9}"                // é
let combinedEAcute: Character = "\u{65}\u{301}" // e followed by ́
// eAcute is é, combinedEAcute is é

print( eAcute )
print( combinedEAcute )


let precomposed: Character = "\u{D55C}"                 // 한
let decomposed: Character = "\u{1112}\u{1161}\u{11AB}"  // ᄒ, ᅡ, ᆫ
print( precomposed )
print( decomposed )

let enclosedEAcute: Character = "\u{E9}\u{20DD}"
// enclosedEAcute is é⃝

let regionalIndicatorForUS: Character = "\u{1F1FA}\u{1F1F8}"
// regionalIndicatorForUS is 🇺🇸

let regionalIndicatorForAUS: Character = "\u{1F1E6}\u{1F1FA}"
// regionalIndicatorForAUS is 🇦🇺

// Counting Characters
let unusualMenagerie = "Koala 🐨, Snail 🐌, Penguin 🐧, Dromedary 🐪"
print("unusualMenagerie has \(unusualMenagerie.count) characters")
// prints "unusualMenagerie has 40 characters"

let unusualMenagerie0 = "Koala, Snail, Penguin, Dromedary"
print("unusualMenagerie0 has \(unusualMenagerie0.count) characters")

var word = "cafe"
print("the number of characters in \(word) is \(word.count)")

word += "\u{301}" // Combining Acute accent, U+301
print("the number of characters in \(word) is \(word.count)")


let greeting = "Guten Tag!"
print( greeting[greeting.startIndex] )
// G
print( greeting[greeting.index(before: greeting.endIndex)] )
// !
print( greeting[greeting.index(after: greeting.startIndex)] )
// u
let index = greeting.index(greeting.startIndex, offsetBy: 7)
print( greeting[index] )

for index in greeting.indices {
    print("\(greeting[index]) ", terminator: "")
}

for index in greeting.indices {
    print("\n\(greeting[index]) AT INDEX:  \(index) ", terminator: "")
}

let someString1 = "AAAA"
for index in someString1.indices {
    print("\n\(someString1[index]) AT INDEX:  \(index) ", terminator: "")
}

/*
var welcome = "hello"
welcome.insert("!", at: welcome.endIndex)
// welcome now equals "hello!"


welcome.insert(contentsOf: " there", at: welcome.index(before: welcome.endIndex))
// welcome now equals "hello there!"

welcome.remove(at: welcome.index(before: welcome.endIndex))
// welcome now equals "hello there"


let range = welcome.index(welcome.endIndex, offsetBy: -6)..<welcome.endIndex
welcome.removeSubrange(range)
// welcome now equals "hello"

let greeting = "Hello, world!"
let index = greeting.firstIndex(of: ",") ?? greeting.endIndex
let beginning = greeting[..<index]
*/


/* FOLLOWING LOGIC SHOULD NOT BE USED IN SWIFT
// Convert the result to a String for long-term storage.
let newString = String(beginning)
compareStringsManually(str1: String, str2: String, caseSensitive: Boolean = true): Int {
    val length1 = str1.length
    val length2 = str2.length
 
    val minLength = if (length1 < length2) length1 else length2
 
    for (i in 0 until minLength) {
        val char1 = str1[i]
        val char2 = str2[i]
         
        if (caseSensitive) {
            if (char1 != char2) return char1 - char2
        } else {
            if (char1.lowercaseChar() != char2.lowercaseChar()) return char1.lowercaseChar() - char2.lowercaseChar()
        }
    }
 
    return length1 - length2 
}

*/


let quotation = "We're a lot alike, you and I."
let sameQuotation = "We're a lot alike, you and I."

if quotation == sameQuotation {
    print("These two strings are considered equal")
} else {
    print("Unequal")
}


// "Voulez-vous un café?" using LATIN SMALL LETTER E WITH ACUTE
let eAcuteQuestion = "Voulez-vous un caf\u{E9}?"

// "Voulez-vous un café?" using LATIN SMALL LETTER E and COMBINING ACUTE ACCENT
let combinedEAcuteQuestion = "Voulez-vous un caf\u{65}\u{301}?"
print( eAcuteQuestion)
print( combinedEAcuteQuestion)

if eAcuteQuestion == combinedEAcuteQuestion {
    print("These two strings are considered equal")
} else {
    print("Unequal")
}

let latinCapitalLeterA: Character = "\u{41}"
let cyrillicCapitalLetterA: Character = "\u{0410}"

print( latinCapitalLeterA )
print( cyrillicCapitalLetterA)
if latinCapitalLeterA != cyrillicCapitalLetterA {
    print("These two characters are not equivalent")
}




// Prefix and Suffix Equality
let romeoAndJuliet = [
    "Act 1 Scene 1: Verona, A public place",
    "Act 1 Scene 2: Capulet's mansion",
    "Act 1 Scene 3: A room in Capulet's mansion",
    "Act 1 Scene 4: A street outside Capulet's mansion",
    "Act 1 Scene 5: The Great Hall in Capulet's mansion",
    "Act 2 Scene 1: Outside Capulet's mansion",
    "Act 2 Scene 2: Capulet's orchard",
    "Act 2 Scene 3: Outside Friar Lawrence's cell",
    "Act 2 Scene 4: A street in Verona",
    "Act 2 Scene 5: Capulet's mansion",
    "Act 2 Scene 6: Friar Lawrence's cell"
]
var act1SceneCount = 0
for scene in romeoAndJuliet {
    if scene.hasPrefix("Act 1") {
        act1SceneCount += 1
    }
}
print("There are \(act1SceneCount) scenes in Act 1")

var mansionCount = 0
var cellCount = 0
for scene in romeoAndJuliet {
    if scene.hasSuffix("Capulet's mansion") {
        mansionCount += 1
    } else if scene.hasSuffix("Friar Lawrence's cell") {
        cellCount += 1
    }
}
print("\(mansionCount) mansion scenes; \(cellCount) cell scenes")

// Unicode Representations of Strings
let dogString = "Dog!!🐶"

for something in dogString {
    print( something )
}

// UTF-8 Representation
for codeUnit in dogString.utf8 {
    print("\(codeUnit) ", terminator: "")
}
print("")

// UTF-16 Representation
for codeUnit in dogString.utf16 {
    print("\(codeUnit) ", terminator: "")
}
print("")




