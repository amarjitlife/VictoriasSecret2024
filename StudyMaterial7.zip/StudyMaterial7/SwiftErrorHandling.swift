
//_______________________________________________________

// Representing and Throwing Errorsin page link

// In Swift, errors are represented by values of types 
// that conform to the Error protocol. 

// This empty protocol indicates that a type can be used for error handling.

// Swift enumerations are particularly well suited to modeling a 
// group of related error conditions, with associated values 
// allowing for additional information about the nature of an 
// error to be communicated.

//_______________________________________________________

enum VendingMachineError: Error {
	case invalidSelection
	case insufficientFunds( coinsNeeded: Int )
	case outOfStock
}

// Fatal error: Error raised at top level: 
// errorhandling.VendingMachineError.insufficientFunds(coinsNeeded: 100)
// throw VendingMachineError.insufficientFunds( coinsNeeded: 100 )


// Note
// Only throwing functions can propagate errors. 
// Any errors thrown inside a nonthrowing function 
// must be handled inside the function.

func canThrowErrors() throws -> String {
	return "DummyData"
}

func cannotThrowErrors() -> String {
	return "DummyData"
}


//_______________________________________________________

struct Item {
    var price: Int
    var count: Int
}

class VendingMachine {
    var inventory = [
        "Candy Bar": Item(price: 12, count: 7),
        "Chips": Item(price: 10, count: 4),
        "Pretzels": Item(price: 7, count: 11)
    ]

    var coinsDeposited = 0

    func vend(itemNamed name: String) throws {
        // Validation Logic
        guard let item = inventory[name] else {
            throw VendingMachineError.invalidSelection
        }

        guard item.count > 0 else {
            throw VendingMachineError.outOfStock
        }

        guard item.price <= coinsDeposited else {
            throw VendingMachineError.insufficientFunds(coinsNeeded: item.price - coinsDeposited)
        }

        coinsDeposited -= item.price

        var newItem = item
        newItem.count -= 1
        inventory[name] = newItem

        print("Dispensing \(name)")
    }
}

let favoriteSnacks = [
    "Alice": "Chips",
    "Bob": "Licorice",
    "Eve": "Pretzels",
]

// Propogating Error
// buyFavoriteSnack Further Throwing Error
func buyFavoriteSnack(person: String, vendingMachine: VendingMachine) throws {
    let snackName = favoriteSnacks[person] ?? "Candy Bar"

    // Throwing Function Should Be Called With try
    try vendingMachine.vend(itemNamed: snackName)
}

var vendingMachine = VendingMachine()
vendingMachine.coinsDeposited = 8

// Error Handling with do-catch
do {
    try buyFavoriteSnack(person: "Alice", vendingMachine: vendingMachine)
    print("Success! Yum.")
} catch VendingMachineError.invalidSelection {
    print("Invalid Selection.")
} catch VendingMachineError.outOfStock {
    print("Out of Stock.")
} catch VendingMachineError.insufficientFunds(let coinsNeeded) {
    print("Insufficient funds. Please insert an additional \(coinsNeeded) coins.")
} catch {
    print("Unexpected error: \(error).")
}
// Prints "Insufficient funds. Please insert an additional 2 coins."

//_______________________________________________________

enum LuckyError : Error {
    case UnLucky
    case UnFortunate
}

func someThrowingFunction(success: Int) throws -> Int {
    // Some Dummy Logic
    if success == 0 { throw LuckyError.UnLucky }
    return Int(success)
}

// let x = try? someThrowingFunction(success: 10)
// print( x )

// Converting Exception i.e. Error Nullability
let x = try? someThrowingFunction(success: 0)
print( x ?? "Nullable Came.." )

// Following Code Is Equivalent To Above Two Lines Of Code
let xx: Int?
do {
    xx = try someThrowingFunction(success: 10)
} catch {
    xx = nil
}

// DESIGN PRACTICES
//      Try Convert Exceptions To Nullables
//      Nullables To Non Nullable

//_______________________________________________________

struct Data { 
    var value = 99.99
}

func fetchDataFromDisk(success: Int) throws -> Data {
    if success == 0 { throw LuckyError.UnLucky }
    return Data()
}

func fetchDataFromServer(success: Int) throws -> Data {
    if success == 0 { throw LuckyError.UnLucky }
    return Data()
}

// Wrapping Error Throwing APIs Inside Nullable APIs
func fetchData() -> Data? {
    // Handling Exceptions and Converting To Nullables
    if let data = try? fetchDataFromDisk( success: 10 ) { return data }
    if let data = try? fetchDataFromServer( success : 0 ) { return data }
    return nil
}

print( fetchData() ?? "Unknown Data" )


//_______________________________________________________

enum FileError: Error {
    case endOfFile
    case fileClosed
}

func exists(filename: String) -> Bool { return true }

class FakeFile {
    var isOpen = false
    var filename = ""
    var lines = 100

    func readline() throws -> String? {
        if self.isOpen {
            if lines > 0 {
                lines -= 1
                return "line number \(lines) of text\n"
            } else {
                throw FileError.endOfFile
                //return nil
            }
        } else {
            throw FileError.fileClosed
        }
    }
}

func open(filename: String) -> FakeFile {
    let file = FakeFile()
    file.filename = filename
    file.isOpen = true
    print("\(file.filename) has been opened")
    return file
}

func close(file: FakeFile) {
    file.isOpen = false
    print("\(file.filename) has been closed")
}

func processFile(filename: String) throws {
    if exists(filename: filename) {
        let file = open(filename: filename)
        defer { // This Code Execution Deffered Till Return From Enclosing Function
            close(file: file)
        }

        while let line = try file.readline() {
            // Work with the file
            print(line)
        }
        // close(file: file) is called here, at the end of the scope.
    }

    // close(file: file)
    // Defer Code Will Execute Just Before Return From The Function
}

do {
    try processFile(filename: "myFakeFile")
} catch FileError.endOfFile {
    print("Reached the end of the file")
} catch FileError.fileClosed {
    print("The file isn't open")
}


//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________


