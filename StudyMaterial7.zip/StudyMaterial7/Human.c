
#include <stdio.h>

typedef struct human_type {
	int id;  			// State
	char name[100];  	// State
	void (*dance)(); 	// Meta-State
} Human; // Defined Human Type


void doBhangra() {
	printf("\nBallleeee Ballleee!!!!");
}

void doBharatnatayam() {
	printf("\nDoing Bharat Natyaam");
}

void playWithHuman() {
	// Creating gabbar Instance/Object Of Type Human
	///				// Constructor Call
	Human gabbar = { 420, "Gabbar Singh", doBhangra };
	printf("\n   ID: %d", gabbar.id );
	printf("\n Name: %s", gabbar.name );

	// Sending dance Message To gabbar Object/Instance
	gabbar.dance();
	//	Object Capabilities
	//		1. Ability To Recieve Message
	//		2. Lookup In Table 
	//				[Message To Method Mapping Table] Generated Based On Type
	//		3. Correspoding Method Exists For Message
	//				Than It Will Map Message To Method
	//		4. Method Call Happens

	Human basanti = { 100, "Basanti", doBharatnatayam };
	printf("\n   ID: %d", basanti.id );
	printf("\n Name: %s", basanti.name );	
	basanti.dance();
}

int main() {
	playWithHuman();
} 

