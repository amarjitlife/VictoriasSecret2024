
//_______________________________________________________
//
// GENERICS
//_______________________________________________________

// What Is Generics?

func swapTwoInts(a: inout Int, b: inout Int) {
	let temp = a
	a = b
	b = temp
}

var first 	= 11
var second 	= 22

print( first )
print( second )

swapTwoInts( a: &first, b: &second)
print( first )
print( second )

//--------------------------------

func swapTwoStrings(a: inout String, b: inout String) {
	let temp = a
	a = b
	b = temp
}

var first1 	= "Hello!"
var second1 = "Hi!"

print( first1 )
print( second1 )

swapTwoStrings( a: &first1, b: &second1)
print( first1 )
print( second1 )

//--------------------------------

func swapTwoDoubles(a: inout Double, b: inout Double) {
	let temp = a
	a = b
	b = temp
}

var first2 	= 90.90
var second2 = 80.80

print( first2 )
print( second2 )

swapTwoDoubles( a: &first2, b: &second2)
print( first2 )
print( second2 )

//_______________________________________________________
//
// Generic Function
//_______________________________________________________

// Generics : Code Template
//		A Code Template Used To Generate Code
//		By Substituting Type Information At Compile Time
//			i.e. Type Placeholders Replaced With Type

// T Is A Type Placeholder
//		T Will Get Substituted By Compiler At Compile Time

// Polymorphic Function
//		Compile Time Polymorphism
func swapTwoValues<T>( a: inout T, b: inout T ) {
	let temp = a
	a = b
	b = temp
}

print( first )
print( second )

// first Type Is Int and second Type Is Int
//		Compiler Will Replace T PlaceHolder With Int Type
//		and Generate Following Code
// func swapTwoValues<Int>( a: inout Int, b: inout Int ) {
// 		let temp = a
// 		a = b
// 		b = temp
// }

swapTwoValues( a: &first, b: &second)
print( first )
print( second )

print( first1 )
print( second1 )

swapTwoValues( a: &first1, b: &second1)
print( first1 )
print( second1 )

print( first2 )
print( second2 )

swapTwoValues( a: &first2, b: &second2)
print( first2 )
print( second2 )

//_______________________________________________________
//_______________________________________________________


struct IntStack {
    var items = [Int]()

    mutating func push(item: Int) {
        items.append(item)
    }

    mutating func pop() -> Int {
        return items.removeLast()
    }
}

struct StringStack {
    var items = [String]()
    mutating func push(item: String) {
        items.append(item)
    }
    mutating func pop() -> String {
        return items.removeLast()
    }
}

struct DoubleStack {
    var items = [Double]()
    mutating func push(item: Double) {
        items.append(item)
    }
    mutating func pop() -> Double {
        return items.removeLast()
    }
}


//_______________________________________________________
//
// Generic Structure 
//_______________________________________________________

struct Stack<T> {
    var items = [T]()

    mutating func push(item: T) {
        items.append(item)
    }

    mutating func pop() -> T {
        return items.removeLast()
    }
}

var stackOfStrings = Stack<String>()
// struct Stack<String> {
//     var items = [String]()
//     mutating func push(item: String) {
//         items.append(item)
//     }
//     mutating func pop() -> String {
//         return items.removeLast()
//     }
// }

stackOfStrings.push(item: "uno")
stackOfStrings.push(item: "dos")
stackOfStrings.push(item: "tres")
stackOfStrings.push(item: "cuatro")

let fromTheTop = stackOfStrings.pop()
print( fromTheTop )


//_______________________________________________________
//
// Type Constraints
//_______________________________________________________

class SomeClass { }
protocol SomeProtocol { }

// Multiple Type Placeholders
//		Here T and U Are Type PlaceHolders
//		T Must Be SubClass Of SomeClass
//		U Must Be Conforming To SomeProtocol
func someFunction<T: SomeClass, U: SomeProtocol>(someT: T, someU: U) {
    // function body goes here
}

func findStringIndex(array: [String], valueToFind: String) -> Int? {
    for (index, value) in array.enumerated() {
        if value == valueToFind {
            return index
        }
    }
    return nil
}

//-------------------

let strings = ["cat", "dog", "Modi", "parakeet", "terrapin"]

if let foundIndex = findStringIndex(array: strings, valueToFind: "Modi") {
    print("The index of llama is \(foundIndex)")
}

// func findIndex<T>(array: [T], valueToFind: T ) -> Int? {

func findIndex<T: Equatable>(array: [T], valueToFind: T) -> Int? {
    for (index, value) in array.enumerated() {
        if value == valueToFind {
            return index
        }
    }
    return nil
}

let doubleIndex = findIndex(array: [3.14159, 0.1, 0.25], valueToFind: 9.3)
print( doubleIndex ?? "[UNKNOWN]")

let stringIndex = findIndex(array: ["Mike", "Malcolm", "Andrea"], valueToFind: "Andrea")
print( stringIndex ?? "[UNKNOWN]")


//_______________________________________________________
//
// Where Clauses
//_______________________________________________________


protocol Container {
    associatedtype ItemType
    var count: Int { get }

    subscript(i: Int) -> ItemType {get }
    mutating func append(item: ItemType)
}

func allItemsMatch<C1: Container, C2: Container>
        (_ someContainer: C1, _ anotherContainer: C2) -> Bool
	        where C1.ItemType == C2.ItemType, C1.ItemType: Equatable {

    // Check that both containers contain the same number of items.
    if someContainer.count != anotherContainer.count {
        return false
    }


    // Check each pair of items to see if they're equivalent.
    for i in 0..<someContainer.count {
        if someContainer[i] != anotherContainer[i] {
            return false
        }
    }

    // All items match, so return true.
    return true
}


//_______________________________________________________

struct Stack2<T> : Container {
    // original Stack<T> implementation
    var items = [T]()
    mutating func push(item: T) {
        items.append(item)
    }

    mutating func pop() -> T {
        return items.removeLast()
    }

    // conformance to the Container protocol
    mutating func append(item: T) {
        self.push(item: item)
    }
    
    var count: Int {
        return items.count
    }
    
    subscript(i: Int) -> T {
        return items[i]
    }
}

//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________

