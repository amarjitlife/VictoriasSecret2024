
//_______________________________________________________

// Property Requirements

// Property requirements are 
        // always declared as variable properties, 
        // prefixed with the var keyword.

protocol SomeProtocol {
    var mustBeSettable: Int 		 { get set }
    var doesNotNeedToBeSettable: Int { get }
}

protocol AnotherProtocol {
    static var someTypeProperty: Int { get set }
}

//_______________________________________________________

// Mathematically 
//		Type 			= { Operations, Range }
//		Abstract Type 	= { Operations, ϕ }
//		Object 			= { States, Meta-States }
//							Minimum Meta-State To Receive and Handle Messages
//							Because Object Has Ability Receive Messages
//		Variable 		= { States, ϕ }

//	Object/Instance Capabilities
//		1. Ability To Recieve Message
//		2. Lookup In Table 
//				[Message To Method Mapping Table] Generated Based On Type
//		3. Correspoding Method Exists For Message
//				Than It Will Map Message To Method
//		4. Method Call Happens

// In Object Oriented Design/Paradigm
//		Objects Talks With Each Others Through Message Passing

//_______________________________________________________
//
// Conforming Class and Structure To A Protocol
//_______________________________________________________

// Creating	Abstract Type 	= { Operations, ϕ }
//		Operations = { getFullName: () -> String }
//		Range = ϕ
// What To Do?
protocol FullyNamed {
    var fullName: String { get }
}

// Concrete Structure
// How, When, Which, Why To Do?
struct Person: FullyNamed {
	// error: type 'Person' does not conform to protocol 'FullyNamed'
    // var fullName: String

    var fullName: String // Property Defined with Generated Getter
}

let john = Person( fullName: "John AppleSeed" )
print( john )
print( john.fullName )

// Concrete Classes
// How, When, Which, Why To Do?
class Starship: FullyNamed {
    var prefix: String?
    var name: String
    
    init(name: String, prefix: String? = nil) {
        self.name = name
        self.prefix = prefix
    }

 	// error: type 'Starship' does not conform to protocol 'FullyNamed'    
    var fullName: String { // Property Defined with Custom Getter
	    return ((prefix != nil ? prefix! + " " : "") + name)
    }
}

var ncc1701 = Starship(name: "Enterprise", prefix: "USS")
print( ncc1701.fullName )

//_______________________________________________________
//
// Conforming Class To A Protocol
//_______________________________________________________

// Creating	Abstract Type 	= { Operations, ϕ }
//		Operations = { random: () -> Double }
//		Range = ϕ

// What To Do?
protocol RandomNumberGenerator {
	func random() -> Double
}

// Creating	Concrete Type 	= { Operations, Range }
//		Operations = { random: () -> Double }
//		Range = { lastRandom, m, a, c }
// linear congruential generator:
class LinearCongruentialGenerator: RandomNumberGenerator {
    var lastRandom = 42.0
    let m = 139968.0
    let a = 3877.0
    let c = 29573.0
    func random() -> Double {
        lastRandom = ((lastRandom * a + c)
            .truncatingRemainder(dividingBy:m))
        return lastRandom / m
    }
}
let generator = LinearCongruentialGenerator()
print("Here's a random number: \(generator.random())")
// Prints "Here's a random number: 0.3746499199817101"
print("And another one: \(generator.random())")
// Prints "And another one: 0.729023776863283"

//_______________________________________________________
//
// Conforming Enumerations To A Protocol
//_______________________________________________________

protocol Togglable {
	mutating func toggle()
}

enum OnOffSwitch: Togglable {
	case Off, On

	mutating func toggle() {
		switch self {
			case .Off:
				self = .On
			case .On:
				self = .Off
		}
	}
}

var ligthSwitch = OnOffSwitch.Off
print( ligthSwitch )
ligthSwitch.toggle()
print( ligthSwitch )


//_______________________________________________________
//_______________________________________________________

// What To Do?
protocol Superpower {
	func fly()
	func saveWorld()
}

// How To Do?
// Making Spiderman Type of Superpower Type
class Spiderman : Superpower {
	func fly() 		 { print("Fly Like Spiderman!") }
	func saveWorld() { print("Save World Like Spiderman!") }
}

// How To Do?
// Making Superman Type of Superpower Type
class Superman : Superpower {
	func fly() 		 { print("Fly Like Superman!") }
	func saveWorld() { print("Save World Like Superman!") }
}

// How To Do?
// Making Heman Type of Superpower Type
class Heman : Superpower {
	func fly() 		 { print("Fly Like Heman!") }
	func saveWorld() { print("Save World Like Heman!") }
}

class Wonderwoman : Superpower {
	func fly() 		 { print("Fly Like Wonderwoman!") }
	func saveWorld() { print("Save World Like Wonderwoman!") }
}

print("\nHumanDesign1....")


// Using Previous Funtionality 
///		Using Inheritance Mechanims

// class HumanDesign1 : Superman {
// class HumanDesign1 : Heman {
class HumanDesign1 : Spiderman {
	override func fly() 	  { super.fly() } 		// { print("Fly Like Human!") }
	override func saveWorld() { super.saveWorld() } // { print("Save World Like Human!") }
}

let human1 = HumanDesign1()
human1.fly()
human1.saveWorld()

print("\nHumanDesign2....")
// Using Previous Funtionality 
//		Using Composition Mechanims

// HENCE COMPOSITION IS EQUIVALENT TO INHERITANCE

// DESIGN PRINCIPLE
//		ALWAYS PREFER COMPOSITION OVER INHERITANCE

class HumanDesign2 {
	// var power = Spiderman()
	// var power = Superman()
	var power = Heman()

	func fly() 	  { power.fly() } 		// { print("Fly Like Human!") }
	func saveWorld() { power.saveWorld() } // { print("Save World Like Human!") }
}

let human2 = HumanDesign2()
human2.fly()
human2.saveWorld()

// In Composition Design
//		Delegation Pattern
//			One Is Delegator and Another Is Delegate
//			HumanDesign3 Is Delegator and power Is Delegate
// 		Substraction Is Possible
print("\nHumanDesign3....")

// Polymorphic Type/Class
//		Runtime Polymorphism
class HumanDesign3 {
	// Very Important Use Case Of Nullability
	// nil Value Representing ZERO For Human
	var power: Superpower? = nil 	//	Human Have No Power

	func fly() 	  	 { power?.fly() } 		// { print("Fly Like Human!") }
	func saveWorld() { power?.saveWorld() } // { print("Save World Like Human!") }
}

let human3 = HumanDesign3()
human3.fly()
human3.saveWorld()

// error: cannot assign value of type 'Spiderman' to type '(any Superpower)?
human3.power = Spiderman()
human3.fly()
human3.saveWorld()

// In Composition Design
// 		Substraction Is Possible
human3.power = nil
human3.fly()
human3.saveWorld()

human3.power = Superman()
human3.fly()
human3.saveWorld()

human3.power = Heman()
human3.fly()
human3.saveWorld()

human3.power = Wonderwoman()
human3.fly()
human3.saveWorld()

//_______________________________________________________
//_______________________________________________________


// protocol RandomNumberGenerator {
// 	func random() -> Double
// }

class Dice {
    let sides: Int

    let generator: RandomNumberGenerator

    init(sides: Int, generator: RandomNumberGenerator) {
        self.sides = sides
        self.generator = generator
    }

    func roll() -> Int {
        return Int(generator.random() * Double(sides)) + 1
    }
}

var dice6 = Dice(sides: 6, generator: LinearCongruentialGenerator())
for _ in 1...5 {
    print("Random dice roll is \(dice6.roll())")
}

//_______________________________________________________
//_______________________________________________________

protocol DiceGame {
    var dice: Dice { get }
    func play()
}

protocol DiceGameDelegate {
    func gameDidStart(game: DiceGame)
    func game(game: DiceGame, didStartNewTurnWithDiceRoll diceRoll: Int)
    func gameDidEnd(game: DiceGame)
}

class SnakesAndLadders: DiceGame {
    let finalSquare = 25
    let dice = Dice(sides: 6, generator:LinearCongruentialGenerator())
    var square = 0
    var board: [Int]
    init() {
        board = [Int](repeating: 0, count: finalSquare + 1)
        board[03] = +08; board[06] = +11; board[09] = +09; board[10] = +02
        board[14] = -10; board[19] = -11; board[22] = -02; board[24] = -08
    }
    var delegate: DiceGameDelegate?
    func play() {
        square = 0
        delegate?.gameDidStart(game: self)
        gameLoop: while square != finalSquare {
            let diceRoll = dice.roll()
            delegate?.game(game: self, didStartNewTurnWithDiceRoll: diceRoll)
            switch square + diceRoll {
            case finalSquare:
                break gameLoop
            case let newSquare where newSquare > finalSquare:
                continue gameLoop
            default:
                square += diceRoll
                square += board[square]
            }
        }
        delegate?.gameDidEnd(game: self)
    }
}

class DiceGameTracker: DiceGameDelegate {
    var numberOfTurns = 0
    func gameDidStart(game: DiceGame) {
        numberOfTurns = 0
        if game is SnakesAndLadders {
            print("Started a new game of Snakes and Ladders")
        }
        print("The game is using a \(game.dice.sides)-sided dice")
    }
 
    func game(game: DiceGame, didStartNewTurnWithDiceRoll diceRoll: Int) {
        numberOfTurns += 1
        print("Rolled a \(diceRoll)")
    }
 
    func gameDidEnd(game: DiceGame) {
        print("The game lasted for \(numberOfTurns) turns")
    }
}

let tracker = DiceGameTracker()
let game = SnakesAndLadders()
game.delegate = tracker
game.play()


//_______________________________________________________
//
// Adding Protocol Conformance with an Extension
//_______________________________________________________

// class Dice : TextRepresentable {
// class Dice {
//     let sides: Int
//     let generator: RandomNumberGenerator

//     init(sides: Int, generator: RandomNumberGenerator) {
//         self.sides = sides
//         self.generator = generator
//     }

//     func roll() -> Int {
//         return Int(generator.random() * Double(sides)) + 1
//     }
// }

protocol TextRepresentable {
    func asText() -> String
}

// Making Dice Class Conforming To TextRepresentable
//		Using Extension Mechanims
extension Dice : TextRepresentable {
	// Using Extension Adding Functionality To Existing Class/Structure/Type
	//		And This Functionality Confirms To TextRepresentable Protocol
    func asText() -> String {
        return "A \(sides)-sided dice"
    }
}

let dice12 = Dice(sides: 12, generator: LinearCongruentialGenerator())
print( dice12.asText() )
print( dice6.asText() )

// Making SnakesAndLadders Class Conforming To TextRepresentable
//		Using Extension Mechanims
extension SnakesAndLadders: TextRepresentable {
    func asText() -> String {
        return "A game of Snakes and Ladders with \(finalSquare) squares"
    }
}

print(game.asText())


//_______________________________________________________
//
// Declaring Protocol Adoption with an Extension
//_______________________________________________________

//  If a type already conforms to all of the requirements of a protocol, 
        // but has not yet stated that it adopts that protocol, 
        // you can make it adopt the protocol with an empty extension:

// protocol TextRepresentable {
//     func asText() -> String
// }

// struct Hamster : TextRepresentable {

struct Hamster {
    var name: String

    func asText() -> String {
        return "A hamster named \(name)"
    }
}

// Making Hamster Structure Confirms To Protocol Adoption with an Extension
//		It Makes Hamster Of Type Of TextRepresentable
extension Hamster: TextRepresentable {

}

let simonTheHamster = Hamster(name: "Simon")
let somethingTextRepresentable: TextRepresentable = simonTheHamster
print(somethingTextRepresentable.asText())


//_______________________________________________________
//
// Collections of Protocol Types
//_______________________________________________________

let things: [ TextRepresentable ] = [ game, dice12, simonTheHamster ]

for thing in things {
    print( thing.asText() )
}

//_______________________________________________________
// 
// Mutliple Protocols Comformance
//_______________________________________________________


//For Example
/*
protocol MulipleProtocol: SomeProtocol, AnotherProtocol {
    // protocol definition goes here
}
*/

// Defined Above, Adding Here For Reference 
// protocol TextRepresentable {
//     func asText() -> String
// }

protocol PrettyTextRepresentable: TextRepresentable {
    func asPrettyText() -> String
}

// PrettyTextRepresentable must satisfy all of the requirements 
// enforced by TextRepresentable, plus the additional requirements 
// enforced by PrettyTextRepresentable.

extension SnakesAndLadders: PrettyTextRepresentable {
    
    func asPrettyText() -> String {
        var output = asText() + ":\n"
        for index in 1...finalSquare {
            switch board[index] {
            case let ladder where ladder > 0:
                output += "▲ "
            case let snake where snake < 0:
                output += "▼ "
            default:
                output += "○ "
            }
        }
        return output
    }
}

print( game.asPrettyText() )


//_______________________________________________________
//_______________________________________________________

// Initializer Requirements
// Protocols can require specific initializers 
        // to be implemented by conforming types.

/*
protocol SomeProtocol {
    init(someParameter: Int)
}

// Class Implementations of Protocol Initializer Requirements
// You can implement a protocol initializer requirement 
        // on a conforming class as either a designated initializer 
        // Or a convenience initializer. 
        // In both cases, you must mark the initializer implementation 
                // with the required modifier

class SomeClass: SomeProtocol {
    required init(someParameter: Int) {
        // initializer implementation goes here
    }
}
*/

// If a subclass overrides a designated initializer from a superclass, 
// and also implements a matching initializer requirement from a protocol, 
// mark the initializer implementation with 
// both the required and override modifiers

/*
protocol SomeProtocol {
    init()
}

class SomeSuperClass {
    init() {
        // initializer implementation goes here
    }
}

class SomeSubClass: SomeSuperClass, SomeProtocol {
    // "required" from SomeProtocol conformance; "override" from SomeSuperClass
    required override init() {
        // initializer implementation goes here
    }
}
*/

//_______________________________________________________
//_______________________________________________________

struct Vector3D : Equatable {
    var x = 0.0, y = 0.0, z = 0.0
}


let twoThreeFour = Vector3D(x: 2.0, y: 3.0, z: 4.0)
let anotherTwoThreeFour = Vector3D(x: 2.0, y: 3.0, z: 4.0)

if twoThreeFour == anotherTwoThreeFour {
    print("These two vectors are also equivalent.")
}

// Prints "These two vectors are also equivalent."

//_______________________________________________________

enum SkillLevel: Comparable {
    case beginner
    case intermediate
    case expert(stars: Int)
}

var levels = [SkillLevel.intermediate, SkillLevel.beginner,
              SkillLevel.expert(stars: 5), SkillLevel.expert(stars: 3)]

for level in levels.sorted() {
    print(level)
}

// Prints "beginner"
// Prints "intermediate"
// Prints "expert(stars: 3)"
// Prints "expert(stars: 5)"


//_______________________________________________________
//
// Class-Only Protocols
//_______________________________________________________

protocol SomeInheritedProtocol: SomeProtocol, AnotherProtocol {
    // protocol definition goes here
}

protocol SomeClassOnlyProtocol: AnyObject, SomeInheritedProtocol {
    // class-only protocol definition goes here
}

//_______________________________________________________
//
// Protocol Composition
//_______________________________________________________

protocol Named {
    var name: String { get }
}

protocol Aged {
    var age: Int { get }
}

struct PersonAgain: Named, Aged {
    var name: String
    var age: Int
}

func wishHappyBirthday(to celebrator: Named & Aged) {
    print("Happy birthday, \(celebrator.name), you're \(celebrator.age)!")
}

let birthdayPerson = PersonAgain(name: "Malcolm", age: 21)
wishHappyBirthday(to: birthdayPerson)
// Prints "Happy birthday, Malcolm, you're 21!"


class Location {
    var latitude: Double
    var longitude: Double
    init(latitude: Double, longitude: Double) {
        self.latitude = latitude
        self.longitude = longitude
    }
}

class City: Location, Named {
    var name: String
    init(name: String, latitude: Double, longitude: Double) {
        self.name = name
        super.init(latitude: latitude, longitude: longitude)
    }
}

func beginConcert(in location: Location & Named) {
    print("Hello, \(location.name)!")
}


let seattle = City(name: "Seattle", latitude: 47.6, longitude: -122.3)
beginConcert(in: seattle)
// Prints "Hello, Seattle!"

//_______________________________________________________


protocol HasArea {
    var area: Double { get }
}

class Circle: HasArea {
    let pi = 3.1415927
    var radius: Double
    var area: Double { return pi * radius * radius }
    init(radius: Double) { self.radius = radius }
}

class Country: HasArea {
    var area: Double
    init(area: Double) { self.area = area }
}

class Animal {
    var legs: Int
    init(legs: Int) { self.legs = legs }
}

let objects: [AnyObject] = [
    Circle(radius: 2.0),
    Country(area: 243_610),
    Animal(legs: 4)
]

for object in objects {
    if let objectWithArea = object as? HasArea {
        print("Area is \(objectWithArea.area)")
    } else {
        print("Something that doesn't have an area")
    }
}
// Area is 12.5663708
// Area is 243610.0
// Something that doesn't have an area


//_______________________________________________________

// It;s Already Defined Above Copied Here For Reference
/*
protocol RandomNumberGenerator {
	func random() -> Double
}
*/

extension RandomNumberGenerator {
    func randomBool() -> Bool {
        return random() > 0.5
    }
}

extension PrettyTextRepresentable  {
    var prettyTextualDescription: String {
        return textualDescription
    }
}

//_______________________________________________________
// 
// Adding Constraints to Protocol Extensions
//_______________________________________________________

extension Collection where Element: Equatable {
    func allEqual() -> Bool {
        for element in self {
            if element != self.first {
                return false
            }
        }
        return true
    }
}

//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________


