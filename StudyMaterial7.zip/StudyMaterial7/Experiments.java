
class NumberDemo {
    public static void playWithNumbers() {
        System.out.println(1.0 / 0.0); 
        System.out.println(-1.0 / 0.0); 
        System.out.println(0.0 / 0.0); 

    // Infinity
    // -Infinity
    // NaN: Non A Number

        System.out.println(1 / 0); 
        System.out.println(-1 / 0); 
        System.out.println(0 / 0); 
    }
}

class Experiments {
    public static void main(String []args) {
        System.out.println("My First Java Program.");

        System.out.println("Function: playWithNumbers");
        NumberDemo.playWithNumbers();
    }
};

