
// _____________________________________________________________
// _____________________________________________________________
// Instance Methods

class Counter {
	// Instance Property
    var count = 0

    // Instance Methods
    func increment() {
        count = count + 1
    }

    func incrementBy(amount: Int) {
        count += amount
    }

    func reset() {
        count = 0
    }
}

let counter = Counter()
counter.increment()
counter.incrementBy(amount: 5)
counter.reset()

// _____________________________________________________________

class CounterTwo {
    var count: Int = 0

    func incrementBy(amount: Int, numberOfTimes: Int) {
        count += amount * numberOfTimes
    }
}

let counter2 = CounterTwo()
counter2.incrementBy(amount: 5, numberOfTimes:3)


// _____________________________________________________________

struct Point {
    var x = 0.0, y = 0.0
    
   	// Instance Member Function
    func isToTheRightOfX(x: Double) -> Bool {
        return self.x > x
    }
}

let somePoint = Point(x: 4.0, y: 5.0)
print( somePoint )
print( somePoint.isToTheRightOfX(x : 1.0) )

// _____________________________________________________________

// Transforming State
struct PointAgain {
    var x = 0.0, y = 0.0

    // Instance Member Function
    // func moveByX( deltaX: Double, deltaY: Double ) {
    mutating func moveByX( deltaX: Double, deltaY: Double ) {
    	// error: cannot assign to property: 'self' is immutable
    	self.x = x + deltaX
    	y = y + deltaY
    }
}

var somePointAgain = PointAgain(x : 1.0, y: 1.0 )
print( somePointAgain )
somePointAgain.moveByX( deltaX: 10.0, deltaY: 10.0 )
print( somePointAgain )


// Transforming State
struct PointOnceAgain {
    var x = 0.0, y = 0.0
    mutating func moveByX(deltaX: Double, y deltaY: Double) {
        self = PointOnceAgain(x: x + deltaX, y: y + deltaY)
    }
}

// _____________________________________________________________


enum TriStateSwitch {
    case Off, Low, High

    mutating func next() {
        switch self {
        case .Off:
            self = .Low
        case .Low:
            self = .High
        case .High:
            self = .Off
        }
    }
}

var ovenLight = TriStateSwitch.Low
print( ovenLight)

ovenLight.next()
print( ovenLight)

ovenLight.next()
print( ovenLight)

ovenLight.next()
print( ovenLight)


// _____________________________________________________________
// _____________________________________________________________
// _____________________________________________________________
// _____________________________________________________________
// _____________________________________________________________
// _____________________________________________________________


