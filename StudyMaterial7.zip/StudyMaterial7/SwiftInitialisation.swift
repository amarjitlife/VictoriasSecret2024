
//_______________________________________________________
//
// Memberwise Initialisers 
//_______________________________________________________

//_______________________________________________________
//
// >>>>>>> MOMENT YOU ARE DONE! PLEASE RAISE YOUR HAND!!!
//_______________________________________________________

struct Fahrenheit {
	// var temperature: Double
	var temperature: Double = 9.9

	// Definining Initialiser i.e. Constructore
	// init() {
	// 		temperature = 32.0
	// }
}

// By Default Memberwise Initialiser Will Be Generated
// If You Provide Your Initialiser
//		Than Memberwise Will Not Be Generated

// error: missing argument for parameter 'temperature' in call
// SwiftInitialisation.swift:6:8: note: 'init(temperature:)' declared here
// let f = Fahrenheit()
// print( f.temperature )

// Using Memberwise Initialiser
let ff = Fahrenheit(temperature: 88.0)
print( ff.temperature )

let ff1 = Fahrenheit() // Farenheit( temperator: 9.9 )
print( ff1.temperature )


//_______________________________________________________
//
// >>>>>>> MOMENT YOU ARE DONE! PLEASE RAISE YOUR HAND!!!
//_______________________________________________________


struct Celsius {
	var temperatureInCelsius: Double = 90.90

	// Overloaded Constructors/Initialsers Based On Parameter Name
	//		Because Parameter Name Is Part Of The Signature
	init( fromFahrenheit fahrenheit: Double ) {
		temperatureInCelsius = ( fahrenheit - 32 ) / 1.8 
	}

	init( fromKelvin kelvin: Double ) {
		temperatureInCelsius = kelvin - 273.15
	}

	// Here _ Means Don't Generate External Parameter Name
	init( _ celsius: Double ) {
		temperatureInCelsius = celsius
	}
}

let boilingPointOfWater = Celsius( fromFahrenheit: 212.0 )
let freezingPointOfWater = Celsius( fromKelvin: 272.15 )

print( boilingPointOfWater.temperatureInCelsius )
print( freezingPointOfWater.temperatureInCelsius )

// Avoid This Style Of Usage
// Using Constructor Like Java With Labels/External Parameter Name
let bodyTemperator = Celsius( 37.0 )
print( bodyTemperator )

//_______________________________________________________
//
// >>>>>>> MOMENT YOU ARE DONE! PLEASE RAISE YOUR HAND!!!
//_______________________________________________________

// Local and External Parameter Names Will Be Same

struct Color {
    let red, green, blue: Double

    init(red: Double, green: Double, blue: Double) {
        self.red   = red
        self.green = green
        self.blue  = blue
    }

    init(white: Double) {
        red     = white
        green   = white
        blue    = white
    }
}

let magenta = Color(red: 1.0, green: 0.0, blue: 1.0)
let halfGray = Color(white: 0.5)

print( magenta )
print( halfGray )

// error: missing argument labels 'red:green:blue:' in call
// let verGreen = Color(0.0, 1.0, 0.0)


//_______________________________________________________
//
// >>>>>>> MOMENT YOU ARE DONE! PLEASE RAISE YOUR HAND!!!
//_______________________________________________________


class SurveyQuestion {
    var text: String
    // Optional Property Type Member
    //		Optional Properties Get Initialised To nil By Default
    var response: String?

    init(text: String) {
        self.text = text
        // self.response = nil
    }

    func ask() {
        print(text)
    }
}

let cheeseQuestion = SurveyQuestion(text: "Do you like cheese?")
cheeseQuestion.ask()
cheeseQuestion.response = "Yes, I do like cheese."
print( cheeseQuestion.response ?? "Nothingness")


// Assigning Constant Properties During Initialization

class SurveyQuestion2 {
	// Constant Property
    let text: String
    // let text: String = "Helloooooo"
    var response: String?
    
    init(text: String) {
    	// error: return from initializer without initializing all stored properties
        // self.text = text
        self.text = text
    }
    
    func ask() {
        print(text)
    }
}

let beetsQuestion = SurveyQuestion2(text: "How about beets?")
beetsQuestion.ask()
beetsQuestion.response = "I also like beets. (But not with cheese.)"

//_______________________________________________________
//
// >>>>>>> MOMENT YOU ARE DONE! PLEASE RAISE YOUR HAND!!!
//_______________________________________________________

struct SizeFirst {
	var width = 0.0
	var height = 0.0
}

// By Default 
//		In Structure Memberwise Initialiser Will Be Generated
let twoByTwo = SizeFirst( width: 2.0, height: 2.0 )
print( twoByTwo )

//	You Can Call Initialser Without Any Parameters
//			Provided Default Values Are Given In Definition
let sizeZero = SizeFirst() // SizeFirst( width: 0.0, height: 0.0 )
print( sizeZero )


// By Default 
//		In Classes NO Arguments Initialiser Will Be Generated
class ShopplingListItem {
	var name: String? = nil
	var quantity = 1
	var purchased = false
}

// 		error: argument passed to call that takes no arguments
// var item = ShopplingListItem(name: "Lux", quantity: 10, purchased: true)
var item = ShopplingListItem()
print( item.name ?? "Uknown", item.quantity, item.purchased )

//_______________________________________________________
//
// >>>>>>> MOMENT YOU ARE DONE! PLEASE RAISE YOUR HAND!!!
//_______________________________________________________

struct Size {
    var width = 0.0, height = 0.0
}

struct Point {
    var x = 0.0, y = 0.0
}

struct Rect {
    var origin = Point()
    var size = Size()

    // Constructors/Initialsers Can Be Overloaded Based On
    //		1. Number Of Arguments
    //		2. Type Of Arguments
    //		3. Parameters Names
    init() {}

    init(origin: Point, size: Size) {
        self.origin = origin
        self.size = size
    }

    init(center: Point, size: Size) {
        let originX = center.x - (size.width / 2)
        let originY = center.y - (size.height / 2)
        self.init(origin: Point(x: originX, y: originY), size: size)
    }
}

let basicRect = Rect()
print( basicRect )

let originRect = Rect(origin: Point(x: 2.0, y: 2.0), 
    size: Size(width: 5.0, height: 5.0))
print( originRect )

let centerRect = Rect(center: Point(x: 4.0, y: 4.0), 
    size: Size(width: 3.0, height: 3.0))
print( centerRect )


//_______________________________________________________
//
// >>>>>>> MOMENT YOU ARE DONE! PLEASE RAISE YOUR HAND!!!
//_______________________________________________________

class Vehicle {
	var numberOfWheels: Int = 0
	var maxPassengers: Int  = 0

	func description() -> String {
		return "Vehicle:: \(numberOfWheels) : \(maxPassengers)"
	}
}

let someVehicle = Vehicle()
print( someVehicle.description() )
// Inheriting From Vehicle
//		Vehicle Is A Parent Class
//		Bicycle Is A Child Class

class Bicycle: Vehicle {
	override init() {
		super.init()
		numberOfWheels = 2
	}

	override func description() -> String {
		return "Bicycle:: \(numberOfWheels) : \(maxPassengers)"
	}

}

let bicycle = Bicycle()
print( bicycle.description() )

//_______________________________________________________
//
// >>>>>>> MOMENT YOU ARE DONE! PLEASE RAISE YOUR HAND!!!
//_______________________________________________________

class Food {
	var name: String

	// Designated Initialser
	init( name: String ) {
		print("Food: init( name: String ) Called... ")
		self.name = name
	}

	// error: designated initializer for 'Food' cannot delegate 
	// (with 'self.init'); did you mean this to be a convenience initializer?

	// Convenience Initialser
	// 		Within Class Must Call Designated Initialser Within Class Only
	convenience init() {
		print("Food: init( ) Called... ")

		// Calling Above Initialser Within Class
		self.init( name: "[Unnamed]")
	}
}

let namedFood = Food(name: "Panneer")
print( namedFood.name )

let someFood = Food()
print( namedFood.name )

class RecipeIngredient: Food {
	var quantity: Int

	// Designated Initialser
	//		From Child Class Must Call Designated Initialiser From Parent Class
	init( name: String, quantity: Int ) {
		print( "RecipeIngredient: init( name: String, quantity: Int ) Called..." )
		self.quantity = quantity
		super.init( name: name )
	}

	// Convenience Initialser
	override convenience init( name: String ) {
		print( "RecipeIngredient: init( name: String ) Called..." )

		// Calling Designated Initialiser From Same Class
		//	i.e. init( name: String, quantity: Int ) 
		self.init( name: name, quantity : 1 )
	}
}

let oneMysteryItem = RecipeIngredient()
let oneBacon = RecipeIngredient(name: "Bacon")
let sixEggs = RecipeIngredient(name: "Eggs", quantity: 6)

//  In this example, the superclass for RecipeIngredient is Food, 
        // which has a single convenience initializer called init(). 
        // This initializer is therefore inherited by RecipeIngredient. 
        // The inherited version of init() functions in exactly the 
        // same way as the Food version, 
            // Except that it delegates to the RecipeIngredient version 
            //      of init(name: String) Rather than the Food version.


class ShoppingListItem2: RecipeIngredient {
    // var purchased: Bool
    var purchased: Bool = false

    var description: String {
    	print( "ShoppingListItem2:  description() Called..." )

        var output = "\(quantity) x \(name)"
        output += purchased ? " √" : " ✘"
        return output
    }
}

var breakfastList = [
    ShoppingListItem2(),
    ShoppingListItem2(name: "Bacon"),
    ShoppingListItem2(name: "Eggs", quantity: 6),
]

for item in breakfastList {
    print(item.description)
}

breakfastList[0].name = "Orange Juice"
breakfastList[0].purchased = true

for item in breakfastList {
    print(item.description)
}


//_______________________________________________________

// DESIGN PRINCIPLE
//		CONSTRUCTOR/INITIALSER DESIGN PATTERN
//
// WITHIN CLASS
//		Designated Initialser Within Class
//			Must Initialise Object Fully
//			i.e. Must Initialise All Member Properties 
//		Convenience Initialser Within Class
//			Must Call Designated Initialisers Within Class
//				To Initialise Properties

// INHERITED CLASSES
//		Designated Initialser Of Child Class
//			Must Call Designated Initialser From Parent Class


//_______________________________________________________

// IN JAVA
//		Suppose Human Class
//		Human gabbar = new Human(420, "Gabbar Singh");

// Object Creation Is 2 Stages Process
//		1. new Get Called To Allocate Object
//		   new Is Wrapper On Top Of malloc
//
//			Human * human = ( Human * ) malloc( sizeof( Human ));

//		2. Initialisation Of Object Happens
//			Constructor Call Does Initialisation As Follows
//
//			human.id = 420
//			human.name = "Gabbar Singh"
//			human.address = new Address("Chambal");
//			
//			Constructor Will Return Initialised Human Type Object
//			human = ( Human * ) human

// In C++
//		Human human = Human(); 		// At Stack
//		Human human = new Human(); 	// At Heap

//_______________________________________________________
// Failable Initialisers
///		Will Return Either Valid Object Or Return Not Valid Object( nil )
//		Use When Full Object Constrcution Can Fail
//			Than Return nil

struct Animal {
	let species: String

	// Failable Initialsers
	init?(species: String) {
		if species.isEmpty { return nil }
		self.species = species
	}
}

// Inferred Type From RHS Is Animal?
// let someCreature: Animal = Animal( species : "Giraffe")
let someCreature: Animal? = Animal( species : "Giraffe")

print( someCreature ?? "Unknown" )

let someCreature1 = Animal( species : "")
print( someCreature1 ?? "Unknown" )

let something = Int("223")
print( something ?? "" )

if let giraffe = someCreature {
	print( giraffe )
}

//_______________________________________________________

// Failable Initialisers For Enumerations

enum TemperatureUnit {
	case Kelvin, Celsius, Fahrenheit
	
	init?( symbol: Character ) {
		switch symbol {
		case "K":
			// self = TemperatureUnit.Kelvin
			self = .Kelvin
		case "C":
			self = .Celsius
		case "F":
			self = .Fahrenheit
		default:
			return nil
		}
	}
}

// Type Inferred From RHS Is TemperatureUnit?
let fahrenheitUnit = TemperatureUnit( symbol: "F" ) 

if let something = TemperatureUnit( symbol: "F" ) {
	print( something )
} else {
	print("Uknown Thing")
}

if let something = TemperatureUnit( symbol: "X" ) {
	print( something )
} else {
	print("Uknown Thing")
}

//_______________________________________________________

// Failable Initialisers For Enumerations With Raw Values

enum TempUnit: Character {
	case Kelvin = "K", Celsius = "C", Fahrenheit = "F"
}

// Type Inferred From RHS Is TempUnit?
let fahrenUnit = TempUnit( rawValue: "F" ) 

if let something = TempUnit( rawValue: "F" ) {
	print( something )
} else {
	print("Uknown Thing")
}

if let something = TempUnit( rawValue: "X" ) {
	print( something )
} else {
	print("Uknown Thing")
}

//_______________________________________________________

// Failable Initialisers For Class

class Product {
	let name: String!

	init?( name: String ) {
		self.name = name
		if name.isEmpty{ return nil }

	}
}

if let bowTie = Product( name: "Bow Tie") {
	print( bowTie.name ?? "Unknown Tie" )
}

if let something = Product( name: "") {
	print( something.name ?? "Unknown Tie" )
} else {
	print( "Unknown Things..." )
}

//_______________________________________________________

// Propogation Of Initialisation Failures

// A failable initializer of a class, structure, or enumeration can 
// delegate across to another failable initializer from the same class, 
// structure, or enumeration. 
// Similarly, a subclass failable initializer can delegate up to a 
// superclass failable initializer.

// In either case, if you delegate to another initializer that 
// causes initialization to fail, the entire initialization process 
// fails immediately, and no further initialization code is executed.


class CartItem: Product {
	let quantity: Int!

	init?( name: String, quantity: Int ) {
		self.quantity = quantity
		super.init( name: name )

		if quantity < 1 { return nil }
	}
}

if let twoSocks = CartItem(name: "sock", quantity: 2) {
    print( twoSocks.name ?? "Unknown Name")
    print( twoSocks.quantity ?? "Unknown Quantity" )
}

if let zeroShirts = CartItem(name: "shirt", quantity: 0) {
    print( zeroShirts.name ?? "Unknown Name")
    print( zeroShirts.quantity ?? "Unknown Quantity" )
} else {
    print("Unable to initialize zero shirts")
}

if let oneUnnamed = CartItem(name: "", quantity: 1) {
    print( oneUnnamed.name ?? "Unknown Name")
    print( oneUnnamed.quantity ?? "Unknown Quantity" )
} else {
    print("Unable to initialize one unnamed product")
}

//_______________________________________________________

class Document {
	var name: String?

	init() { }

	init?( name : String ) {
		self.name = name
		if name.isEmpty { return nil }	
	}
}

class AutomaticallyNamedDocument : Document {
   override init() {
        super.init()
        self.name = "[Untitled]"
    }

   // Creating Non Failable Initialser ( It Will Return Non Nullable Object )
    override init(name: String) {
        super.init()
	
	// Converting Nullability To Non Nullability
        if name.isEmpty {
            self.name = "[Untitled]"
        } else {
            self.name = name
        }
    }
}


//_______________________________________________________

// Note that the closure’s end curly brace is followed by an empty pair of parentheses. 
// 		This tells Swift to execute the closure immediately. 
// 		If you omit these parentheses, you are trying to assign the 
//		closure itself to the property, and not the return value of the closure.

class SomeClass {
	// Assinging Default Values Using Closures/Functions
	let someProperty : Int = { // Initialing With Closure/Lamdba Expression
		return 1234
	}() // Invoking Lambda Expression 


	let someProperty2 = { // Initialing With Closure/Lamdba Expression
		return 1234
	}

	let someProperty3 : Int = 1234

	var somePropertyAgain : Int { //Getter For somePropertyAgain
		return 9999
	}
}

let someObject = SomeClass()
print( someObject.someProperty )
print( someObject.someProperty2 )
print( someObject.someProperty3 )
print( someObject.somePropertyAgain )

//_______________________________________________________

struct Checkerboard {
    
    let boardColors: [Bool] = {
        var temporaryBoard = [Bool]()
        var isBlack = false
        for i in 1...10 {
            for j in 1...10 {
                temporaryBoard.append(isBlack)
                isBlack = !isBlack
            }
            isBlack = !isBlack
        }
        return temporaryBoard
    }()

    func squareIsBlackAtRow(row: Int, column: Int) -> Bool {
        return boardColors[(row * 10) + column]
    }
}

let board = Checkerboard()
print(board.squareIsBlackAtRow(row: 0, column: 1))
print(board.squareIsBlackAtRow(row: 9, column: 9))
print( board )

//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
