
//_______________________________________________________
//
// Operator Overloading
//_______________________________________________________


struct Vector2D {
	var x = 0.0, y = 0.0
}

// Overloaded + Operator For Vector2D Type
func + ( left: Vector2D, right: Vector2D ) -> Vector2D {
	return Vector2D( x: left.x + right.x , y: left.y + right.y )
}

let vector1 = Vector2D(x: 10.0, y: 20.0)
let vector2 = Vector2D(x: 30.0, y: 40.0)
print( vector1 )
print( vector2 )

let vector3 = Vector2D( x: vector1.x + vector2.x , y: vector1.y + vector2.y )
print( vector3 )

//error: binary operator '+' cannot be applied to two 'Vector2D' operands
let vector3Again = vector1 + vector2
print( vector3Again )

func - ( left: Vector2D, right: Vector2D ) -> Vector2D {
	return Vector2D( x: left.x - right.x , y: left.y - right.y )
}

let vector3OnceAgain = vector1 - vector2
print( vector3OnceAgain )

prefix func - ( vector: Vector2D ) -> Vector2D {
	return Vector2D( x: -vector.x , y: -vector.y )
}

let vector3OnceMore = -vector2
print( vector3OnceMore )

// Compound Assignment Operators
func += (  left: inout Vector2D, right: Vector2D) {
    left = left + right
}

var original = Vector2D(x: 1.0, y: 2.0)
let vectorToAdd = Vector2D(x: 3.0, y: 4.0)
original += vectorToAdd
print( original )


func == (left: Vector2D, right: Vector2D) -> Bool {
    return (left.x == right.x) && (left.y == right.y)
}

func != (left: Vector2D, right: Vector2D) -> Bool {
    return !(left == right)
}

let twoThree = Vector2D(x: 2.0, y: 3.0)
let anotherTwoThree = Vector2D(x: 2.0, y: 3.0)

if twoThree == anotherTwoThree {
    print("These two vectors are equivilent.")
} else {
	print("Not Equal!")
}


//_______________________________________________________
//
// Custom Operators
// Custom operators can be defined only with the characters 
        // = - + * / % < > ! & | ^ . ~
//_______________________________________________________

// +++ prefix doubling incrementer

prefix operator +++ //{}

prefix func +++ ( vector: inout Vector2D) -> Vector2D {
    vector += vector
    return vector
}

var toBeDoubled = Vector2D(x: 1.0, y: 4.0)
let afterDoubling = +++toBeDoubled
print( toBeDoubled )
print( afterDoubling )

//_______________________________________________________
//
//
//_______________________________________________________


//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
