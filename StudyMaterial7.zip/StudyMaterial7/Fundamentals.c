
#include <stdio.h>

void playWithPointers() {
	int a = 20;
	int *ptr = &a;

	printf("\n Value of a: %d", a);
	printf("\n Value At Address ptr: %d", *ptr);	

	printf("\n Address of a: %x", &a);	
	printf("\n Address of a: %x", ptr);	
}

// Function Type
//		(int, int) -> int

// Function Name
//		It's Starting Address Of Function Body
int sum( int x, int y) { return x + y; }
int sub( int x, int y) { return x - y; }

void playWithFunctionPointers() {
	int a = 40;
	int b = 20;
	int result = 0;
	int (*doSomething )(int, int);

//	In Java/Kotlin
//		::sum Returns Reference To Function sum
//			i.e. Starting Address Of sum Function Body
	doSomething = sum;

	result = doSomething(a, b);
	printf("\nResult %d", result);

	doSomething = sub;
	result = doSomething(a, b);
	printf("\nResult %d", result);	
}

// Function: playWithFunctionPointers
// Result 60
// Result 20

int main() {
	printf("\n\nFunction: playWithPointers");
	playWithPointers();

	printf("\n\nFunction: playWithFunctionPointers");
	playWithFunctionPointers();

	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
}

