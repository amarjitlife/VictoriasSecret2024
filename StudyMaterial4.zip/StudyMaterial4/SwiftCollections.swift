// Arrays
// Creating an Empty Array
var someInts = [Int]()
print("someInts is of type [Int] with \(someInts.count) items.")

// Creating an Array with a Default Value
var threeDoubles = Array(repeating: 0.0, count: 3)
// threeDoubles is of type [Double], and equals [0.0, 0.0, 0.0]

// Creating an Array by Adding Two Arrays Together

var anotherThreeDoubles = Array(repeating: 2.5, count: 3)
// anotherThreeDoubles is of type [Double], and equals [2.5, 2.5, 2.5]
var sixDoubles = threeDoubles + anotherThreeDoubles

print( threeDoubles )
print( anotherThreeDoubles )
print( sixDoubles )

var shoppingList: [String] = ["Eggs", "Milk"]
// shoppingList has been initialized with two initial items
var shoppingList1 = ["Eggs", "Milk"]
// shoppingList has been initialized with two initial items

print( shoppingList )
print( shoppingList1 )

print("The shopping list contains \(shoppingList.count) items.")

if shoppingList.isEmpty {
	print("List Is Empty")
} else {
	print("List Have Data...")
}

shoppingList.append("Flour")
print( shoppingList )

shoppingList += ["Baking Powder"]
// shoppingList now contains 4 items
shoppingList += ["Chocolate Spread", "Cheese", "Butter"]
print( shoppingList )

var firstItem = shoppingList[0]
print( firstItem )

shoppingList[0] = "Coffee"
print( shoppingList )

shoppingList[4...6] = ["Bananas", "Apples"]
print( shoppingList )

shoppingList.insert("Maple Syrup", at: 0)
print( shoppingList )

let mapleSyrup = shoppingList.remove(at: 0)
print( mapleSyrup )

// shoppingList[4] = nil
firstItem = shoppingList[0]
print( firstItem )

let apples = shoppingList.removeLast()
print( apples )

for item in shoppingList {
    print(item)
}

for (index, value) in shoppingList.enumerated() {
    print("Item \(index + 1): \(value)")
}

// Set
// A set stores distinct values of the same type in a collection 
// with no defined ordering. 

// You can use a set instead of an array 
// when the order of items isn’t important, or when you need to ensure that an item only appears once.


var letters = Set<Character>()
print("letters is of type Set<Character> with \(letters.count) items.")
// Prints "letters is of type Set<Character> with 0 items."

letters.insert("a")
// letters now contains 1 value of type Character
letters = []
// letters is now an empty set, but is still of type Set<Character>

var favoriteGenres: Set<String> = ["Rock", "Classical", "Hip hop"]
// favoriteGenres has been initialized with three initial items

var favoriteGenres1: Set = ["Rock", "Classical", "Hip hop"]
print("I have \(favoriteGenres1.count) favorite music genres.")

if favoriteGenres1.isEmpty {
    print("As far as music goes, I'm not picky.")
} else {
    print("I have particular music preferences.")
}
// Prints "I have particular music preferences."
// Prints "I have 3 favorite music genres."

favoriteGenres.insert("Jazz")
// favoriteGenres now contains 4 items

if let removedGenre = favoriteGenres.remove("Rock") {
    print("\(removedGenre)? I'm over it.")
} else {
    print("I never much cared for that.")
}
// Prints "Rock? I'm over it."


if favoriteGenres.contains("Funk") {
    print("I get up on the good foot.")
} else {
    print("It's too funky in here.")
}
// Prints "It's too funky in here."


for genre in favoriteGenres {
    print("\(genre)")
}
// Classical
// Jazz
// Hip hop

for genre in favoriteGenres.sorted() {
    print("\(genre)")
}
// Classical
// Hip hop
// Jazz


let oddDigits: Set = [1, 3, 5, 7, 9]
let evenDigits: Set = [0, 2, 4, 6, 8]
let singleDigitPrimeNumbers: Set = [2, 3, 5, 7]


oddDigits.union(evenDigits).sorted()
// [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
oddDigits.intersection(evenDigits).sorted()
// []
oddDigits.subtracting(singleDigitPrimeNumbers).sorted()
// [1, 9]
oddDigits.symmetricDifference(singleDigitPrimeNumbers).sorted()
// [1, 2, 9]


let houseAnimals: Set = ["🐶", "🐱"]
let farmAnimals: Set = ["🐮", "🐔", "🐑", "🐶", "🐱"]
let cityAnimals: Set = ["🐦", "🐭"]

houseAnimals.isSubset(of: farmAnimals)
// true
farmAnimals.isSuperset(of: houseAnimals)
// true
farmAnimals.isDisjoint(with: cityAnimals)


// Dictionaries
// A dictionary stores associations between keys of the same 
// type and values of the same type in a collection with no 
// defined ordering. Each value is associated with a unique key, 
// which acts as an identifier for that value within the dictionary. 
// Unlike items in an array, items in a dictionary don’t have a 
// specified order


// Dictionaries
let alongFormDict = Dictionary<String, Int>()
let shortFormDict = [String:Int]()


// Creating an Empty Dictionary
var namesOfIntegers = [Int: String]()

namesOfIntegers[16] = "sixteen"
namesOfIntegers = [:]


// Creating a Dictionary with a Dictionary Literal
//var airports: Dictionary<String, String> = ["TYO":"Tokyo", "DUB":"Dublin"]


var airports: [String: String] = ["YYZ":"Toronto Pearson", "DUB":"Dublin"]


// Accessing and Modifying a Dictionary


print("The dictionary of airports contains \(airports.count) items.")

if airports.isEmpty {
    print("The airports dictionary is empty.")
} else {
    print("The airports dictionary is not empty.")
}

airports["LHR"] = "London"
airports["LHR"] = "London Heathrow"

if let oldValue = airports.updateValue("Dublin International", forKey: "DUB") {
    print("The old value for DUB was \(oldValue).")
}

if let airportName = airports["DUB"] {
    print("The name of the airport is \(airportName)")
} else {
    print("That airport is not in the airports dictionary.")
}

airports["APL"] = "Apple International"
airports["APL"] = nil

if let removedValue = airports.removeValue(forKey: "DUB") {
    print("The removed airport's name is \(removedValue).")
} else {
    print("The airports dictionary doesn't contain a value for DUB.")
}
// Prints "The removed airport's name is Dublin Airport."

// Iterating over a dictionary


for (airportCode, airportName) in airports {
    print("\(airportCode): \(airportName)")
}

for airportCode in airports.keys {
    print("Airport code: \(airportCode)")
}

for airportName in airports.values {
    print("Airport name: \(airportName)")
}

let airportCodes = [String](airports.keys)
let airportNames = [String](airports.values)
