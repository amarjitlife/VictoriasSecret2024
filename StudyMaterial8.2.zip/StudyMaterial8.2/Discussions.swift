

Write Following sum Function In C

Calculate Aritmatic Integer Sum 
	Return Valid Aritmatic Sum
	OR
	Print Can't Calculate Sum For Given Values

//______________________________________________

// ATTEMPT 01
int sum(int x, int y) {
	return x + y 
}

//______________________________________________

// ATTEMPT 02
int sum(int x, int y) {
	int total = x + y

	if ( total > x + y || total < x + y ) {

	}
    else {

    }
}

//______________________________________________

// ATTEMPT 03
int sum(int x, int y) {
	int total = x + y

	if ( ( x, y > 0 &&  total < 0 ) || ( x, y < 0 and total > 0 )) {

	}
    else {

    }
}

//______________________________________________

fun outerFunction() {
	var something = 100

	fun localFunction() {
		something = something + 1000
	}

	return ::localFunction
}


val somethingAgain = outerFunction()

val magic = somethingAgain()


//______________________________________________


String greeting = new String("Hello");
greeting = new String("Ola");


//______________________________________________

String greeting = new String("Hello");

void doChange( String something ) {
	something = String("Ola");
}

doChange( greeting );
print( greeting );


//______________________________________________

f1() {
	f11() {

	}
	f12() {

	}
	f13() {

	}
}

f2() {
	f22() {

	}
	f23() {

	}
}

main() {
	f1()
	f2()
}


//______________________________________________

{ L
	{ L1
		{ L11

		}
		
		{ L12

		}
		
		{ L13

		}
	}

	{ L2
		{ L21

		}
		
		{ L22
			
		}
	}
}

//______________________________________________

// In Java

int matrix[4][5];
int matrix[4][5][3];

//______________________________________________

class Human {
	String firstName;
	String middleName;
	String lastName;

	// Main Constructor Or Designated Constructor/Initialiser
	Human(String firstName, String middleName, String lastName ) {
		// Initialisation Logic Initialised Object Fully
		//		Bring At Common Place
		this.firstName 	= firstName
		this.middleName = middleName
		this.lastName 	= lastName
	}

	// Convenience Constructor/Initialiser
	Human( String firstName, String lastName ) {
		this( firstName, null, lastName )
	}

	// Convenience Constructor/Initialiser
	Human( String firstName ) {
		this( firstName, null, null )
	}
}

class Manager extends Human {
	String appraisal;

	// Main Constructor Or Designated Constructor/Initialiser
	Manager(String firstName, String middleName, String lastName, String appraisal ) {
		// Initialisation Logic Initialised Object Fully
		//		Bring At Common Place
		// this.firstName 	= firstName
		// this.middleName = middleName
		// this.lastName 	= lastName
		super( firstName, middleName, lastName )
		this.appraisal = appraisal
	}

	// Convenience Constructor/Initialiser
	Manager( String firstName, String lastName ) {
		this( firstName, null, lastName, null )
	}

	// Convenience Constructor/Initialiser
	Manager( String firstName ) {
		this( firstName, null, null, null )
	}
}

//______________________________________________

// BAD CODE
//		For Validation Don't Use Exception Handling

try {
	n / d
} catch( DivideByZeroException ) {

}

// Do Validation With if-else
if ( d != 0 ) {
	n / d
}


//______________________________________________
//______________________________________________

enum UIApplicationState {
	case UIApplicationStateRunning
	case UIApplicationStateInactive
	case UIApplicationStateActive
	case UIApplicationStateForground
	case UIApplicationStateBackground	
}

class UIApplication {
	var delegate: UIApplicationDelegate?
	var applicationState: UIApplicationState = NotRunning

	func startApp() {
		// Maintains iOS Application State Machine.
		switch state {
			case UIApplicationStateRunning:
				// Methods Calls
				applicationState = UIApplicationStateRunning
				delegate.application:didFinishLauchingWithOption(application: self, )
			case UIApplicationStateInactive:

				applicationState = UIApplicationStateInactive

			case UIApplicationStateActive:
				applicationState = UIApplicationStateState
				delegate.application.willBecomeActive(application: self, )
				// Corresponding Lifecycles Methods Called
			
			case UIApplicationStateForground:
				applicationState = UIApplicationStateForground
				// Corresponding Lifecycles Methods Called
			
			case UIApplicationStateBackground:	
				applicationState = UIApplicationStateForground
				// Corresponding Lifecycles Methods Called

		}
	}
}

class AppDelegate : UIApplicationDelegate {
	func application:willFinishLauchingWithOption {

	}
	
	func application:didFinishLauchingWithOption {

	}
	...
}

func UIApplicationMain() {
	var application = UIApplication()
	var appdelegate = AppDelegate()

	application.delegate = appdelegate
	application.startApp()
}

//______________________________________________
//______________________________________________

