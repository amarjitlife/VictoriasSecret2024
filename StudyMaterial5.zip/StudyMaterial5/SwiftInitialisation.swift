
//_______________________________________________________
//
// Memberwise Initialisers 
//_______________________________________________________

//_______________________________________________________
//
// >>>>>>> MOMENT YOU ARE DONE! PLEASE RAISE YOUR HAND!!!
//_______________________________________________________

struct Fahrenheit {
	// var temperature: Double
	var temperature: Double = 9.9

	// Definining Initialiser i.e. Constructore
	// init() {
	// 		temperature = 32.0
	// }
}

// By Default Memberwise Initialiser Will Be Generated
// If You Provide Your Initialiser
//		Than Memberwise Will Not Be Generated

// error: missing argument for parameter 'temperature' in call
// SwiftInitialisation.swift:6:8: note: 'init(temperature:)' declared here
// let f = Fahrenheit()
// print( f.temperature )

// Using Memberwise Initialiser
let ff = Fahrenheit(temperature: 88.0)
print( ff.temperature )

let ff1 = Fahrenheit() // Farenheit( temperator: 9.9 )
print( ff1.temperature )


//_______________________________________________________
//
// >>>>>>> MOMENT YOU ARE DONE! PLEASE RAISE YOUR HAND!!!
//_______________________________________________________


struct Celsius {
	var temperatureInCelsius: Double = 90.90

	// Overloaded Constructors/Initialsers Based On Parameter Name
	//		Because Parameter Name Is Part Of The Signature
	init( fromFahrenheit fahrenheit: Double ) {
		temperatureInCelsius = ( fahrenheit - 32 ) / 1.8 
	}

	init( fromKelvin kelvin: Double ) {
		temperatureInCelsius = kelvin - 273.15
	}

	// Here _ Means Don't Generate External Parameter Name
	init( _ celsius: Double ) {
		temperatureInCelsius = celsius
	}
}

let boilingPointOfWater = Celsius( fromFahrenheit: 212.0 )
let freezingPointOfWater = Celsius( fromKelvin: 272.15 )

print( boilingPointOfWater.temperatureInCelsius )
print( freezingPointOfWater.temperatureInCelsius )

// Avoid This Style Of Usage
// Using Constructor Like Java With Labels/External Parameter Name
let bodyTemperator = Celsius( 37.0 )
print( bodyTemperator )

//_______________________________________________________
//
// >>>>>>> MOMENT YOU ARE DONE! PLEASE RAISE YOUR HAND!!!
//_______________________________________________________

// Local and External Parameter Names Will Be Same

struct Color {
    let red, green, blue: Double

    init(red: Double, green: Double, blue: Double) {
        self.red   = red
        self.green = green
        self.blue  = blue
    }

    init(white: Double) {
        red     = white
        green   = white
        blue    = white
    }
}

let magenta = Color(red: 1.0, green: 0.0, blue: 1.0)
let halfGray = Color(white: 0.5)

print( magenta )
print( halfGray )

// error: missing argument labels 'red:green:blue:' in call
// let verGreen = Color(0.0, 1.0, 0.0)


//_______________________________________________________
//
// >>>>>>> MOMENT YOU ARE DONE! PLEASE RAISE YOUR HAND!!!
//_______________________________________________________


class SurveyQuestion {
    var text: String
    // Optional Property Type Member
    //		Optional Properties Get Initialised To nil By Default
    var response: String?

    init(text: String) {
        self.text = text
        // self.response = nil
    }

    func ask() {
        print(text)
    }
}

let cheeseQuestion = SurveyQuestion(text: "Do you like cheese?")
cheeseQuestion.ask()
cheeseQuestion.response = "Yes, I do like cheese."
print( cheeseQuestion.response ?? "Nothingness")


// Assigning Constant Properties During Initialization

class SurveyQuestion2 {
	// Constant Property
    let text: String
    // let text: String = "Helloooooo"
    var response: String?
    
    init(text: String) {
    	// error: return from initializer without initializing all stored properties
        // self.text = text
        self.text = text
    }
    
    func ask() {
        print(text)
    }
}

let beetsQuestion = SurveyQuestion2(text: "How about beets?")
beetsQuestion.ask()
beetsQuestion.response = "I also like beets. (But not with cheese.)"

//_______________________________________________________
//
// >>>>>>> MOMENT YOU ARE DONE! PLEASE RAISE YOUR HAND!!!
//_______________________________________________________

struct SizeFirst {
	var width = 0.0
	var height = 0.0
}

// By Default 
//		In Structure Memberwise Initialiser Will Be Generated
let twoByTwo = SizeFirst( width: 2.0, height: 2.0 )
print( twoByTwo )

//	You Can Call Initialser Without Any Parameters
//			Provided Default Values Are Given In Definition
let sizeZero = SizeFirst() // SizeFirst( width: 0.0, height: 0.0 )
print( sizeZero )


// By Default 
//		In Classes NO Arguments Initialiser Will Be Generated
class ShopplingListItem {
	var name: String? = nil
	var quantity = 1
	var purchased = false
}

// 		error: argument passed to call that takes no arguments
// var item = ShopplingListItem(name: "Lux", quantity: 10, purchased: true)
var item = ShopplingListItem()
print( item.name ?? "Uknown", item.quantity, item.purchased )

//_______________________________________________________
//
// >>>>>>> MOMENT YOU ARE DONE! PLEASE RAISE YOUR HAND!!!
//_______________________________________________________

struct Size {
    var width = 0.0, height = 0.0
}

struct Point {
    var x = 0.0, y = 0.0
}

struct Rect {
    var origin = Point()
    var size = Size()

    // Constructors/Initialsers Can Be Overloaded Based On
    //		1. Number Of Arguments
    //		2. Type Of Arguments
    //		3. Parameters Names
    init() {}

    init(origin: Point, size: Size) {
        self.origin = origin
        self.size = size
    }

    init(center: Point, size: Size) {
        let originX = center.x - (size.width / 2)
        let originY = center.y - (size.height / 2)
        self.init(origin: Point(x: originX, y: originY), size: size)
    }
}

let basicRect = Rect()
print( basicRect )

let originRect = Rect(origin: Point(x: 2.0, y: 2.0), 
    size: Size(width: 5.0, height: 5.0))
print( originRect )

let centerRect = Rect(center: Point(x: 4.0, y: 4.0), 
    size: Size(width: 3.0, height: 3.0))
print( centerRect )


//_______________________________________________________
//
// >>>>>>> MOMENT YOU ARE DONE! PLEASE RAISE YOUR HAND!!!
//_______________________________________________________

class Vehicle {
	var numberOfWheels: Int = 0
	var maxPassengers: Int  = 0

	func description() -> String {
		return "Vehicle:: \(numberOfWheels) : \(maxPassengers)"
	}
}

let someVehicle = Vehicle()
print( someVehicle.description() )
// Inheriting From Vehicle
//		Vehicle Is A Parent Class
//		Bicycle Is A Child Class

class Bicycle: Vehicle {
	override init() {
		super.init()
		numberOfWheels = 2
	}

	override func description() -> String {
		return "Bicycle:: \(numberOfWheels) : \(maxPassengers)"
	}

}

let bicycle = Bicycle()
print( bicycle.description() )

//_______________________________________________________
//
// >>>>>>> MOMENT YOU ARE DONE! PLEASE RAISE YOUR HAND!!!
//_______________________________________________________

class Food {
	var name: String

	// Designated Initialser
	init( name: String ) {
		self.name = name
	}

	// error: designated initializer for 'Food' cannot delegate 
	// (with 'self.init'); did you mean this to be a convenience initializer?

	// Convenience Initialser
	// 		Within Class Must Call Designated Initialser Within Class Only
	convenience init() {
		// Calling Above Initialser Within Class
		self.init( name: "[Unnamed]")
	}
}

let namedFood = Food(name: "Panneer")
print( namedFood.name )

let someFood = Food()
print( namedFood.name )

class RecipeIngredient: Food {
	var quantity: Int

	// Designated Initialser
	//		From Child Class Must Call Designated Initialiser From Parent Class
	init( name: String, quantity: Int ) {
		self.quantity = quantity
		super.init( name: name )
	}

	// Convenience Initialser
	override convenience init( name: String ) {
		self.init( name: name, quantity : 1 )
	}
}

let oneMysteryItem = RecipeIngredient()
let oneBacon = RecipeIngredient(name: "Bacon")
let sixEggs = RecipeIngredient(name: "Eggs", quantity: 6)

//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
