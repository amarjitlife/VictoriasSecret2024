
package learnKotlin

//______________________________________________________

fun playWithTypeInferrencingAndBinding() {
	// 1. Type Inferring From RHS
	// 2. Type Binding To LHS
	//		Inferred Type Is Binded To LHS

	//In  Kotlin, Java, C, C++ 
	//		Statically Typed Langauge
	//		Type Is Compile Time Decision
	// In Python
	//		Type Is Runtime Decision

	val something = 10
	println( something )

	// Explicitly Annotating Type Of LHS As Int
	val somethingAgain: Int = 10
	println( somethingAgain )

	val something1 = 90.90
	val somethingAgain1: Double = 90.90
	println( something1 )
	println( somethingAgain1 )

	val something2 = 90.90F
	val somethingAgain2: Float = 90.90F
	println( something2 )
	println( somethingAgain2 )

	val greeting = "Good Evening!"
	val greetingAgain : String = "Good Evening!"
	println( greeting )
	println( greetingAgain )
}

//______________________________________________________
/*
fun playWithInitalValues() {
	val something: Int
	println( something )

	// Explicitly Annotating Type Of LHS As Int
	val somethingAgain: Int = 10
	println( somethingAgain )

	val something1: Double
	val somethingAgain1: Double = 90.90
	println( something1 )
	println( somethingAgain1 )

	val something2: Float
	val somethingAgain2: Float = 90.90F
	println( something2 )
	println( somethingAgain2 )

	val greeting: String
	val greetingAgain : String = "Good Evening!"
	println( greeting )
	println( greetingAgain )
}
*/

//______________________________________________________

interface Expr
class Num( val value: Int ) : Expr
class Sum( val left: Expr, val right: Expr ) : Expr

fun eval( e: Expr ) : Int {
	if ( e is Num ) {
		return e.value
	}

	if ( e is Sum ) {
		return eval( e.left ) + eval( e.right )
	}

	throw IllegalArgumentException("Uknown Arguments")
}

fun playWithEval() {
	println( eval( Sum( Num(100), Num(200) )) )
}

//______________________________________________________

// interface Expr
// class Num( val value: Int ) : Expr
// class Sum( val left: Expr, val right: Expr ) : Expr

fun evalIf0( e: Expr ) : Int {
	return if ( e is Num ) {
		e.value
	} else if ( e is Sum ) {
		evalIf0( e.left ) + evalIf0( e.right )
	} else {
		throw IllegalArgumentException("Uknown Arguments")
	}
}

fun evalIf( e: Expr ) : Int = if ( e is Num ) {
		e.value
	} else if ( e is Sum ) {
		evalIf( e.left ) + evalIf( e.right )
	} else {
		throw IllegalArgumentException("Uknown Arguments")
	}


fun playWithEvalIf() {
	println( evalIf( Sum( Num(100), Num(200) )) )
}

//______________________________________________________

interface Expr
class Num( val value: Int ) : Expr
class Sum( val left: Expr, val right: Expr ) : Expr

// fun evaluate( e: Expr ) : Int = when ( e ) {

// error: type checking has run into a recursive problem. 
// 		Easiest workaround: specify types of your declarations explicitly
// fun evaluate( e: Expr ) = when ( e ) {
fun evaluate( e: Expr ) : Int = when ( e ) {
	is Num -> e.value
	is Sum -> evaluate( e.left ) + evaluate( e.right )
	// when' expression must be exhaustive, add necessary 'else' branch	
	// else -> throw IllegalArgumentException("Uknown Arguments")
}

fun playWithEvaluate() {
	println( evaluate( Sum( Num(100), Num(200) )) )
}

//______________________________________________________

fun sum(x: Int, y: Int) : Int = x + y
fun sumAgain(x: Int, y: Int) = x + y

//______________________________________________________

https://codebunk.com/b/3381100663970/
https://codebunk.com/b/3381100663970/
https://codebunk.com/b/3381100663970/
https://codebunk.com/b/3381100663970/

//______________________________________________________
//______________________________________________________
//______________________________________________________
//______________________________________________________

fun main() {
	println("\nFunction: playWithTypeInferrencingAndBinding")
	playWithTypeInferrencingAndBinding()

	// println("\nFunction: playWithIntialValues")
	// playWithInitalValues()

	println("\nFunction: playWithEval")
	playWithEval()

	println("\nFunction: playWithEvalIf")
	playWithEvalIf()

	println("\nFunction: playWithEvaluate")
	playWithEvaluate()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}