
____________________________________________________________

DAY 01
____________________________________________________________

	Assignment A1 : Reading Assignment [ MUST MUST ]

		Data Type Chapter
		The C Programming Language, 2nd Edition, Kernigham and Denish Ritchie

	Assignment A2 : Thinking, Exploration and Experimentation

____________________________________________________________

DAY 02
____________________________________________________________
	
	Assignment A0 : Practice and Revision Swift Code [ MUST MUST ]
		Practice Swift Code Till Now Done
		Compare Similar Ideas In Java and Kotlin
		Write Sample Codes and Find The Differences

	Assignment A1 : Reading Assignment [ MUST MUST ]
		Chapter: Types, Expressions and Operators
		Reference: 
			The C Programming Language, 2nd Edition
			By Kernigham and Denish Ritchie

	Assignment A2 : Thinking, Exploration and Experimentation
		Lot More Coding Assignment

____________________________________________________________

DAY 03
____________________________________________________________
	
	Assignment A0 : Practice and Revision Swift Code [ MUST MUST ]
		Practice Swift Code Till Now Done
		Compare Similar Ideas In Java and Kotlin
		Write Sample Codes and Find The Differences

	Assignment A1 : Reading Assignment [ MUST MUST ]
		Chapter: Pointers And Arrays
		
		Chapter: Types, Expressions and Operators
		Reference: 
			The C Programming Language, 2nd Edition
			By Kernigham and Denish Ritchie

	Assignment A2 : Thinking, Exploration and Experimentation
		Lot More Coding Assignment

____________________________________________________________

DAY 04
____________________________________________________________
	
	Assignment A0 : Practice and Revision Swift Code [ MUST MUST ]
		Practice Swift Code Till Now Done
		Compare Similar Ideas In Java and Kotlin
		Write Sample Codes and Find The Differences

	Assignment A1 : Reading Assignment [ MUST MUST ]
		Chapter: Pointers And Arrays		
		Reference: 
			The C Programming Language, 2nd Edition
			By Kernigham and Denish Ritchie

	Assignment A2 : Reading And Reasoning Assignments
		https://docs.oracle.com/javase/8/docs/api/java/lang/Object.html#equals-java.lang.Object-
		https://developer.apple.com/documentation/swift/string
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/thebasics/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/basicoperators/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/stringsandcharacters/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/controlflow/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/functions/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/closures/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/enumerations/		

	Assignment A3 : Thinking, Exploration and Experimentation
		Lot More Coding Assignment

____________________________________________________________

DAY 05
____________________________________________________________

	Assignment A0 : Practice and Revision Swift Code [ MUST MUST ]
		Practice Swift Code Till Now Done
		Compare Similar Ideas In Java and Kotlin
		Write Sample Codes and Find The Differences

	Assignment A1 : Reading And Reasoning Assignments
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/enumerations/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/classesandstructures/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/properties/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/methods/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/subscripts/
		 
	Assignment A2 : Thinking, Exploration and Experimentation
		Lot More Coding Assignment

____________________________________________________________

DAY 06
____________________________________________________________

	Assignment A0 : Practice and Revision Swift Code [ MUST MUST ]
		Practice Swift Code Till Now Done
		Compare Similar Ideas In Java and Kotlin
		Write Sample Codes and Find The Differences

	Assignment A1 : Reading And Reasoning Assignments
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/subscripts/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/inheritance/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/initialization/
		
	Assignment A2 : Thinking, Exploration and Experimentation
		Lot More Coding Assignment

____________________________________________________________
____________________________________________________________
____________________________________________________________
____________________________________________________________
____________________________________________________________
____________________________________________________________
____________________________________________________________
____________________________________________________________
