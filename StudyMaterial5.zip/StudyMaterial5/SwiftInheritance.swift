
//_______________________________________________________
//
// >>>>>>> MOMENT YOU ARE DONE! PLEASE RAISE YOUR HAND!!!
//_______________________________________________________

class Vehicle {
	var numberOfWheels: Int
	var maxPassengers: Int

	init() {
		numberOfWheels = 0
		maxPassengers = 1
	}

	func description() -> String {
		return "\(numberOfWheels) : \(maxPassengers)"
	}
}

let someVehicle = Vehicle()

// Inheriting From Vehicle
//		Vehicle Is A Parent Class
//		Bicycle Is A Child Class

class Bicycle: Vehicle {
	override init() {
		super.init()
		numberOfWheels = 2
	}
}

let bicycle = Bicycle()
print( bicycle.description() )

class Tandem: Bicycle {
	override init() {
		super.init()
		maxPassengers = 2
	}
}

let tandem = Tandem()
print( tandem.description() )


//_______________________________________________________
//
// >>>>>>> MOMENT YOU ARE DONE! PLEASE RAISE YOUR HAND!!!
//_______________________________________________________

// Overriding Member Function
class Car: Vehicle {
	var speed: Double = 0.0

	override init() {
		super.init()
		maxPassengers = 5
		numberOfWheels = 4
	}

	override func description() -> String {
		return super.description() + " Speed : \(speed)"
	}
}

let car = Car()
print( car.description() )

// Overriding speed Property
class SpeedLimitedCar: Car {
    override var speed: Double {
	    get {
	        return super.speed
	    }
	    set {
	        super.speed = min(newValue, 40.0)
	    }
    }
}
let limitedCar = SpeedLimitedCar()
limitedCar.speed = 60.0
print("SpeedLimitedCar: \(limitedCar.description())")

//_______________________________________________________
//
// Overriding Property To Add Observers
//_______________________________________________________

class AutomaticCar: Car {
    var gear = 1
    // Overriding Property To Add Observers
    override var speed: Double {
	    didSet {
	        gear = Int(speed / 10.0) + 1
	    }
    }

    override func description() -> String {
        return super.description() + " in gear \(gear)"
    }
}

let automatic = AutomaticCar()
automatic.speed = 35.0
print("AutomaticCar: \(automatic.description())")


// You can use property overriding to add property observers 
// to an inherited property. This enables you to be notified 
// when the value of an inherited property changes, regardless 
// of how that property was originally implemented. 

// Note
// You can’t add property observers to inherited constant 
// stored properties or inherited read-only computed properties. 
// The value of these properties can’t be set, and so it isn’t appropriate 
// to provide a willSet or didSet implementation as part of an override.

// Note 
// also that you can’t provide both an overriding setter and an overriding 
// property observer for the same property. If you want to observe changes 
// to a property’s value, and you are already providing a custom setter 
// for that property, you can simply observe any value changes from 
// within the custom setter.

//_______________________________________________________
//
// BEST PRACTICE
//		Classes Which Are Not Meant To Be Inherited 
//				Must Be Final
//_______________________________________________________
         
// Preventing Overridesin
//	You can prevent a method, property, or subscript from being overridden 
// by marking it as final. 

// Do this by writing the final modifier before the method, property, or subscript’s 
// introducer keyword (such as 

// final var, 
// final func, 
// final class func, and 
// final subscript

// You can mark an entire class as final by writing the final modifier 
// before the class keyword in its class definition 

// final class 

// Any attempt to subclass a final class is reported as a compile-time error.

//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
