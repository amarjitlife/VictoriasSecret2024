
//___________________________________________________________________
//___________________________________________________________________

struct FixedLengthRange {
	var firstValue: Int
	let length: Int
}

var rangeOfThreeItems = FixedLengthRange( firstValue: 0, length: 0 )
print( rangeOfThreeItems )
rangeOfThreeItems.firstValue = 10
print( rangeOfThreeItems )
// FixedLengthRange(firstValue: 0, length: 0)
// FixedLengthRange(firstValue: 10, length: 0)


let rangeOfThreeItemsAgain = FixedLengthRange( firstValue: 0, length: 0 )
print( rangeOfThreeItemsAgain )


// error: cannot assign to property: 
//		'rangeOfThreeItemsAgain' is a 'let' constant
// rangeOfThreeItemsAgain.firstValue = 99
// print( rangeOfThreeItemsAgain )


//___________________________________________________________________

// Always Prefer Struct and Enums Rather Than Classes
//		Uses Classes Only To Achieve Some Design Patterns

class DataImporter {
	var fileName = "data.txt"
}

class DataManager {
	lazy var importer = DataImporter()
	var data = [String]()
}

let manager = DataManager()
manager.data += ["Some Data"]
manager.data += ["Some More Data"]

print( manager.importer.fileName )

//___________________________________________________________________

// Compiler Will Do Following Things
//		It Will Generate Memberwise Initialiser
//		It Will Generate Getters and Setters 
//			For Mutable Property
//				Both Getter and Setter Generated
//			For Immutability 
//				Only Getter Generated
//		It Will Generate Instance Member

struct Point {
	// Stored Properties
	var x = 0.0, y = 0.0
}

struct Size {
	// Stored Properties
	var width = 0.0, height = 0.0
}

struct Rect {
	// Stored Properties Are origin And size
	var origin = Point()
	var size = Size()

	// Computed Properties: center
	var center: Point {
	    get { // Custom Getters and Setters
	        let centerX = origin.x + (size.width / 2)
	        let centerY = origin.y + (size.height / 2)
	        return Point(x: centerX, y: centerY)
	    }

	    set(newCenter) {
	        origin.x = newCenter.x - (size.width / 2)
	        origin.y = newCenter.y - (size.height / 2)
	    }
	}
}

var square = Rect(
					origin: Point(x: 0.0, y: 0.0), 
					size: Size(width: 10.0, height: 10.0)
				)

// RHS Getter Called i.e. square.getCenter()
let initialSquareCenter = square.center 
// LHS Setter Called square.setCenter(Point(x: 15.0, y: 15.0))
square.center = Point(x: 15.0, y: 15.0) 
print("square.origin is now at (\(square.origin.x), \(square.origin.y))")


struct RectAlternative {
	// Stored Properties
	var origin = Point()
	var size = Size()
	var center: Point {
	    get { // Custom Getters and Setters
	        let centerX = origin.x + (size.width / 2)
	        let centerY = origin.y + (size.height / 2)
	        return Point(x: centerX, y: centerY)
	    }

	    set { // You Can Skip Arguments Name In Setter
	    	//		Than Compiler Will Generate newValue Argument Name
	        origin.x = newValue.x - (size.width / 2)
	        origin.y = newValue.y - (size.height / 2)
	    }
	}
}

//___________________________________________________________________


struct Cuboid {
    var width = 0.0, height = 0.0, depth = 0.0

    // volume Is Computed Property
    //		With Getter Defined
    //		i.e. Readonly Computed Property
    var volume: Double {
    	// get { 
	    	return width * height * depth
    	// }
    }
}

let fourByFiveByTwo = Cuboid(width: 4.0, height: 5.0, depth: 2.0)
print("the volume of fourByFiveByTwo is \(fourByFiveByTwo.volume)")

//___________________________________________________________________


// Property Observers
class StepCounter {
	var totalSteps: Int = 0 {
		// set {
		// 	totalSteps = newValue
		// }

		willSet( newTotalSteps ) {
			print("Before Setter Called:  \(newTotalSteps)")
		}

		didSet {
			print("After Setter Called...")			
			if totalSteps > oldValue {
				print("Added \(totalSteps - oldValue) Steps")
			}
		}
	}
}

let stepCounter = StepCounter()
stepCounter.totalSteps = 200
print( stepCounter.totalSteps )

stepCounter.totalSteps = 300
print( stepCounter.totalSteps )

stepCounter.totalSteps = 800
print( stepCounter.totalSteps )

stepCounter.totalSteps = 20000
print( stepCounter.totalSteps )

//___________________________________________________________________

// Type Properties
// Type properties are useful for defining values that are universal 
        // to all instances of a particular type, 
        // such as a constant property that all instances can use (like a static constant in C), or 
        // a variable property that stores a value that is global 
                // to all instances of that type (like a static variable in C).

// Type Property Syntax

struct SomeStructure {
    static var storedTypeProperty = "Some value."
    static var computedTypeProperty: Int {
        return 1
    }
}

enum SomeEnumeration {
    static var storedTypeProperty = "Some value."
    static var computedTypeProperty: Int {
        return 6
    }
}

class SomeClass {
    static var storedTypeProperty = "Some value."

    static var computedTypeProperty: Int {
        return 27
    }

    class var overrideableComputedTypeProperty: Int {
        return 107
    }
}


// Querying and setting Type Properties

print(SomeStructure.storedTypeProperty)             // prints "Some value."
SomeStructure.storedTypeProperty = "Another value."
print(SomeStructure.storedTypeProperty)             // prints "Another value."
print(SomeEnumeration.computedTypeProperty)         // prints "6"
print(SomeClass.computedTypeProperty)               // prints "27"


//___________________________________________________________________

// BAD EXAMPLE
struct AudioChannel {
    static let thresholdLevel = 10
    static var maxInputLevelForAllChannels = 0
    var currentLevel: Int = 0 {
        didSet {
            if currentLevel > AudioChannel.thresholdLevel {
                // cap the new audio level to the threshold level
                currentLevel = AudioChannel.thresholdLevel
            }
            if currentLevel > AudioChannel.maxInputLevelForAllChannels {
                // store this as the new overall maximum input level
                AudioChannel.maxInputLevelForAllChannels = currentLevel
            }
        }
    }
}

var leftChannel = AudioChannel()
var rightChannel = AudioChannel()
leftChannel.currentLevel = 7
print(leftChannel.currentLevel)
print(AudioChannel.maxInputLevelForAllChannels)
rightChannel.currentLevel = 11
print(rightChannel.currentLevel)
print(AudioChannel.maxInputLevelForAllChannels)

//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________


